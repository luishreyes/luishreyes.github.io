---
name: uniandes-design
description: Use this skill to generate well-branded interfaces and assets for the Universidad de los Andes (Colombia), either for production or for throwaway prototypes, lecture slides, teaching materials and mocks. Contains essential design guidelines, institutional colors, typography (Dax + IBM Plex), the shield logo, and a set of slide templates tuned for classroom use.
user-invocable: true
---

Read the `README.md` file within this skill first — it contains the full brand context, content fundamentals, visual foundations and iconography guidance.

Then explore the other available files:

- `colors_and_type.css` — CSS variables for colors, typography, spacing, radii, shadows, motion. Import this at the top of any artifact.
- `assets/` — institutional logo (`logo-uniandes-colombia.png`) and a simplified shield SVG.
- `preview/` — small preview cards that demonstrate each token or component in isolation.
- `slides/` — ready-to-use slide templates for Prof. Luis H. Reyes's lectures. `slides/index.html` is a running deck.

If creating visual artifacts (slides, mocks, throwaway prototypes, posters, handouts, course pages), copy the relevant assets out of `assets/` and `slides/` and create static HTML files that import `colors_and_type.css` — it self-hosts Dax and loads IBM Plex, so no extra font stylesheet is required.

If working on production code, copy the CSS variables, read the guidance in `README.md`, and become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design — a lecture slide deck, a single poster, a course homepage, a handout, a syllabus, a quiz template — then ask a few specific questions (course name, class number, topic, audience, bilingual or Spanish-only, how many slides, with/without images) and act as an expert designer who outputs HTML artifacts or production code, depending on the need.
