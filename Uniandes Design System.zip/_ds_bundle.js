/* @ds-bundle: {"format":3,"namespace":"UniandesDesignSystem_e412e6","components":[],"sourceHashes":{},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.UniandesDesignSystem_e412e6 = window.UniandesDesignSystem_e412e6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

})();
