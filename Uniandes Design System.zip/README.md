# Uniandes Design System

A design system for **Prof. Luis H. Reyes** — class presentations and teaching materials rooted in the Universidad de los Andes (Colombia) institutional identity.

This system translates the **Manual de Identidad Institucional 2021** into tokens, components and slide templates that can be used to produce lectures, handouts, prototypes, and course websites that feel unmistakably uniandino.

---

## Sources

All guidance below is derived from publicly-available Uniandes identity materials. No private/internal brand assets were provided to this repo.

- **Manual de Identidad Institucional 2021 (PDF)** — <https://www.uniandes.edu.co/sites/default/files/2024-10/manual-imagen-2021.pdf>
- **Identidad institucional · FAQ** — <https://www.uniandes.edu.co/es/la-universidad/historia-mision-y-simbolos/identidad-institucional>
- **Logosímbolos + plantillas PowerPoint** — <https://donaciones.uniandes.edu.co/es/universidad/informacion-general/identidad-institucional/logosimbolos>
- **Historia, misión y símbolos** — <https://www.uniandes.edu.co/es/la-universidad/historia-mision-y-simbolos>
- User-uploaded logo: `assets/logo-uniandes-colombia.png` (the "Universidad de los Andes · Colombia" lockup)

> ⚠️ The official logosímbolos are distributed as EPS / WMF from Uniandes. Replace the SVG stand-in in `assets/uniandes-shield.svg` with the licensed vector for any public-facing material.

---

## Brand in one paragraph

Universidad de los Andes is a private, secular, research-focused university founded in Bogotá in 1948. Its visual identity is austere, confident and deliberately restrained: **black and yellow**, strong geometry, and the unmistakable **shield with a single-stroke tree** drawn by Sergio Trujillo Magnenat and refined in later updates. The tone is academic but warm — Spanish first, bilingual where useful, institutionally formal without feeling corporate. Values the university leans on are **Excelencia, Integridad, Libertad, Solidaridad**.

---

## Content Fundamentals

**Language.** Spanish is primary; English is acceptable for bilingual materials and international audiences. Use **español neutro colombiano** — no regionalismos, no slang.

**Tone.** Formal-humanist. The university speaks from authority without being cold. It is *académica* but not distant; confident without being boastful. For teaching materials specifically, the tone may relax slightly — direct, curious, invitational — but never colloquial.

**Voice — first person.**
- For institutional communication: third person or the first-person *nosotros/nuestro* (e.g. "En Uniandes ofrecemos una educación de excelencia a lo largo de la vida").
- For teaching materials by a specific professor: professor speaks as *yo* in notes, but uses *ustedes* (not *vosotros*) when addressing students directly — this is Colombian standard.
- Avoid *tú* in official slides; use *usted* or *ustedes*.

**Casing.** Sentence case for headlines and slide titles. **Never** Title Case English-style. ALL CAPS is reserved for eyebrows, tags and the occasional section label in the wider tracking.

**Numerals.** Spanish conventions: `1.948` (period as thousands separator), `3,14` (comma as decimal). Dates: `16 de noviembre de 1948`.

**Punctuation.** Opening inverted marks are mandatory: `¿…?` and `¡…!`. Use « » for pull-quotes in editorial contexts; plain " " is fine in slides and UI.

**Emoji.** Do not use. The institutional voice is emoji-free. Teaching materials may use a single ✦ / → / § as a typographic ornament, but never smileys.

**Examples** (real voice from uniandes.edu.co):
> «En Uniandes ofrecemos una educación de excelencia a lo largo de la vida, personalizada y flexible, que acoge a personas diversas.»

> «Vivimos experiencias universitarias memorables, colaborativas y globales.»

> «Una institución autónoma, independiente e innovadora que propicia el pluralismo, la tolerancia y el respeto de las ideas.»

Teaching-voice equivalent (Prof. Reyes):
> «Hoy vamos a pensar juntos en un problema que, a primera vista, parece trivial.»
> «Antes de abrir el código, fíjense en la estructura.»

---

## Visual Foundations

**Palette.** The institutional palette is only two colors: **black (#000000)** and **yellow (#FFFF00)**. For screen use we recommend a slightly muted `#FFD100` to avoid vibration on large fills; the pure `#FFFF00` stays reserved for the shield. A quiet set of neutral grays, plus a small accent set (red, blue, forest, teal, ochre) is available for secondary/faculty use. Full tokens in `colors_and_type.css`.

**Type.** Display is **Dax** (custom institutional, by Hans Reichel — FontFont). Dax is a humanist-geometric sans with narrow apertures, a slightly condensed feel and distinctive two-story `a`. It is used for the logosímbolo, titles and display copy. The licensed Dax files are now **self-hosted** in `fonts/`, so display copy renders in the real institutional face. For body copy we pair it with **IBM Plex Sans** — refined, neutral, highly legible, and explicitly *not* one of the over-used defaults. **IBM Plex Serif** is available for long-form editorial. See `colors_and_type.css`.

> ✅ Dax is now **self-hosted** from `fonts/` (licensed files supplied by the user). Display copy renders in the real institutional face — no substitution is in effect.

**Spacing.** 4px base grid. Generous vertical rhythm; avoid dense corporate layouts. Slides and printed pages should breathe — the Manual itself uses wide margins and plenty of negative space.

**Backgrounds.** White or warm off-white (`--uni-bone`) for most surfaces. Black is a primary background for emphasis — section dividers, title slides, quotes. Yellow is powerful; use it as an accent rather than an entire background, and pair with black text only. No gradients. No noisy textures. No decorative patterns.

**Imagery.** Photographic, grounded, humanist. Campus architecture, students mid-activity, hands and materials, Bogotá light (cool, overcast, natural). Warm black-and-white is welcome for archival or editorial feeling. Avoid stocky office imagery and over-saturated marketing photography. When imagery is unavailable, use **full-bleed color blocks** (yellow on black, black on yellow, or neutral-on-neutral) — this is the institutional "placeholder" move.

**Animation.** Restrained. Use opacity fades and slight y-translations. `cubic-bezier(0.2, 0, 0, 1)` for standard transitions (120–220ms). No bounces, no scale-pops, no spring physics. Page/slide transitions should feel like turning a printed page.

**Hover states.** Opacity dip (to `0.8`) OR underline thickens OR background shifts one step up in the gray ramp. Never color-shift to a new hue.

**Press states.** Background one step darker; no scale-down.

**Focus states.** 2px solid `--uni-black` outline with `2px` offset — high-contrast, institutional, accessible. Never remove focus rings.

**Borders.** 1px hairlines in `--uni-mist` for default separation; 1px black for emphasis; 2px black for the identity-forward "framed" look used in posters and section dividers.

**Shadows.** Understated. Prefer 1px borders to shadows. When elevation is needed, use `--shadow-1` / `--shadow-2` — subtle y-offsets, no blur bloom. **Never** glowy, colored, or layered shadows.

**Transparency & blur.** Avoid. This brand is flat, printed-feeling, high-contrast. Translucency/blur may be used very sparingly for fixed overlays (e.g. a sticky header on scroll).

**Corner radii.** Small. The Uniandes shield has no roundedness; the visual system inherits that. Buttons and inputs: `--radius-md` (4px). Cards: `--radius-lg` (8px). Pills only when semantically a pill (tags, status).

**Cards.** Flat rectangle, 1px border, white or bone fill, `radius-lg`, `shadow-1` optional on hover. No colored left-border accents — that trope is not uniandino.

**Layout rules.**
- Fixed grid: 12 columns, 24px gutters, max content width `1200px`.
- Titles align to a strong baseline at the top of the page or slide.
- Yellow blocks are geometric: full-height side bars, corner accents, caption plates — never freeform.
- The logosímbolo has a reserved area equal to the x-height of the shield on every side; respect it.

---

## Iconography

The Manual de Identidad does not specify an official icon system. Uniandes digital properties (uniandes.edu.co, faculty sites) use **Material Symbols** consistently — you can see them in the live site (e.g. the `arrow_outward`, `keyboard_arrow_down` glyphs in navigation).

**This system therefore standardizes on Material Symbols (Outlined, weight 400, grade 0, optical size 24)** — loaded from Google's CDN. This is a *match* to live Uniandes usage, not a substitution.

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Symbols+Outlined" />
<span class="material-symbols-outlined">arrow_outward</span>
```

**SVG vs PNG.** Prefer SVG. The shield in `assets/uniandes-shield.svg` is a simplified institutional mark for layout use; for official output use the licensed EPS from the Uniandes download center.

**Emoji.** Do not use in institutional materials. Teaching materials may use a single decorative glyph (→, ✦, §) sparingly.

**Unicode as icons.** Acceptable and even encouraged for minimal editorial decoration: `→`, `↗`, `·`, `§`, `¶`, `†`, `‡`. These feel book-like and match the humanist voice.

---

## Index — what's in this project

```
README.md                 ← you are here
SKILL.md                  ← Agent Skill manifest (for Claude Code export)
colors_and_type.css       ← design tokens (CSS vars) + semantic typography
fonts/                    ← self-hosted Dax (institucional, licensed)
assets/
  logo-uniandes-colombia.png   ← the full institutional lockup (user-supplied)
  uniandes-shield.svg          ← simplified shield for layout (see warning above)
preview/                  ← design-system preview cards (registered for the DS tab)
slides/                   ← sample slide templates for Prof. Reyes's lectures
  index.html              ← a running deck using the templates
```

### Preview cards (Design System tab)

| Group       | Card                         | File                                |
|-------------|------------------------------|-------------------------------------|
| Brand       | Logosímbolo                  | preview/logo.html                   |
| Brand       | Shield variations            | preview/shield-variations.html      |
| Colors      | Primary palette              | preview/colors-primary.html         |
| Colors      | Neutral ramp                 | preview/colors-neutrals.html        |
| Colors      | Accent / faculty colors      | preview/colors-accents.html         |
| Colors      | Semantic tokens              | preview/colors-semantic.html        |
| Type        | Display scale (Dax)          | preview/type-display.html           |
| Type        | Body scale (IBM Plex Sans)   | preview/type-body.html              |
| Type        | Roles & pairings             | preview/type-roles.html             |
| Spacing     | Spacing scale                | preview/spacing-scale.html          |
| Spacing     | Radii & shadows              | preview/spacing-radii-shadows.html  |
| Components  | Buttons                      | preview/comp-buttons.html           |
| Components  | Form inputs                  | preview/comp-inputs.html            |
| Components  | Cards & badges               | preview/comp-cards.html             |
| Components  | Callouts                     | preview/comp-callouts.html          |

### Slide templates

| File                         | Purpose                                   |
|------------------------------|-------------------------------------------|
| slides/index.html            | Running deck — demonstrates all templates |
| slides/TitleSlide.jsx        | Cover slide with shield + course info     |
| slides/SectionSlide.jsx      | Section divider (yellow-on-black)         |
| slides/ContentSlide.jsx      | Standard title + body + optional figure   |
| slides/QuoteSlide.jsx        | Big pull-quote with attribution           |
| slides/ComparisonSlide.jsx   | Two-column compare/contrast               |
| slides/BulletsSlide.jsx      | Enumerated points with eyebrow            |
| slides/CodeSlide.jsx         | Code block + commentary (for programming) |
| slides/ClosingSlide.jsx      | ¿Preguntas? + contact                     |

---

## Caveats & open items

- **Dax is self-hosted** in `fonts/` (licensed files supplied by the user) — display copy renders in the real institutional face. Five weights ship: Light 300, Regular 400, Medium 500, Bold 700, Black 900, with italics for 400/500/700.
- The **shield SVG** in `assets/` is a simplified stand-in drawn from the institutional description. For any official/public-facing work, swap it for the licensed EPS/WMF from Uniandes.
- The Manual de Identidad's *secondary* palette (per-faculty colors) is referenced but not exhaustively ingested; if Prof. Reyes's faculty has a specific color, set `--uni-accent-faculty` in your document.
- No sample slide template was supplied, so templates were designed from first principles against the institutional identity.
