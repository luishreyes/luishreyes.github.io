/* Course hub screens for Narrativas Visuales.
   Composes DS primitives from window.NarrativasVisualesDesignSystem_47c612.
   Exposed on window for index.html to mount. */
(function () {
const NV = window.NarrativasVisualesDesignSystem_47c612;
const { Badge, Button, IconButton, Tag, Card, Callout, Tabs, Stat, FigureFrame, ProgressTrack } = NV;

const Ico = ({ n, s = 18, c = "currentColor" }) =>
  <i data-lucide={n} style={{ width: s, height: s, color: c }}></i>;

/* ---- 16-week syllabus (abbreviated content, real structure) ---- */
const WEEKS = [
  { n: 1, title: "Del dato a la decisión", part: "Fundamentos" },
  { n: 2, title: "Contexto y audiencia", part: "Fundamentos" },
  { n: 3, title: "Elegir el gráfico correcto", part: "Fundamentos" },
  { n: 4, title: "Eliminar el desorden", part: "Fundamentos" },
  { n: 5, title: "Dirigir la atención", part: "Fundamentos" },
  { n: 6, title: "Pensar como diseñador", part: "Fundamentos" },
  { n: 7, title: "La historia en los datos", part: "Fundamentos" },
  { n: 8, title: "Taller integrador I", part: "Fundamentos" },
  { n: 9, title: "Planear la presentación", part: "Presentación" },
  { n: 10, title: "Construir el mensaje", part: "Presentación" },
  { n: 11, title: "Diseñar las láminas", part: "Presentación" },
  { n: 12, title: "Entregar con presencia", part: "Presentación" },
  { n: 13, title: "IA como acelerador", part: "Presentación" },
  { n: 14, title: "Prototipos con IA", part: "Presentación" },
  { n: 15, title: "Ética en la comunicación", part: "Presentación" },
  { n: 16, title: "Presentación final", part: "Presentación" },
];

/* ======================= SIDEBAR ======================= */
function Sidebar({ current, onSelect, done }) {
  return (
    <aside style={{
      width: 300, flexShrink: 0, height: "100%", boxSizing: "border-box",
      background: "var(--carbon-950)", borderRight: "1px solid var(--border)",
      display: "flex", flexDirection: "column",
    }}>
      <div style={{ padding: "26px 24px 20px", borderBottom: "1px solid var(--border)" }}>
        <Wordmark />
      </div>
      <div style={{ padding: "20px 24px 8px" }}>
        <ProgressTrack total={16} current={current} label="Progreso" />
      </div>
      <nav style={{ flex: 1, overflowY: "auto", padding: "12px 14px 24px" }}>
        {["Fundamentos", "Presentación"].map((part) => (
          <div key={part} style={{ marginBottom: 14 }}>
            <div style={{
              padding: "10px 10px 8px", fontFamily: "var(--font-text)", fontSize: 10,
              letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-faint)",
            }}>{part}</div>
            {WEEKS.filter((w) => w.part === part).map((w) => {
              const active = w.n === current;
              const isDone = done.includes(w.n);
              return (
                <button key={w.n} onClick={() => onSelect(w.n)} style={{
                  width: "100%", textAlign: "left", display: "flex", alignItems: "center", gap: 12,
                  padding: "10px 10px", marginBottom: 2, cursor: "pointer",
                  background: active ? "var(--surface-hover)" : "transparent",
                  border: "1px solid " + (active ? "var(--border)" : "transparent"),
                  borderLeft: "2px solid " + (active ? "var(--accent)" : "transparent"),
                  borderRadius: "var(--r-1)", transition: "background var(--dur-fast) var(--ease)",
                }}>
                  <span style={{
                    width: 22, height: 22, flexShrink: 0, display: "inline-flex", alignItems: "center", justifyContent: "center",
                    fontFamily: "var(--font-display)", fontSize: 15, fontVariantNumeric: "tabular-nums",
                    color: isDone ? "var(--accent)" : active ? "var(--text)" : "var(--text-faint)",
                    border: "1px solid " + (isDone ? "var(--border-focus)" : "var(--border)"),
                    borderRadius: "var(--r-1)",
                  }}>{isDone ? "✓" : String(w.n).padStart(2, "0")}</span>
                  <span style={{
                    fontFamily: "var(--font-text)", fontSize: 13.5, lineHeight: 1.25,
                    color: active ? "var(--text)" : "var(--text-muted)", fontWeight: active ? 600 : 400,
                  }}>{w.title}</span>
                </button>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
}

function Wordmark() {
  const arm = 12, w = 2, c = "var(--accent)";
  const cn = (extra) => ({ position: "absolute", width: arm, height: arm, ...extra });
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
      <div style={{ position: "relative", width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <span style={cn({ top: 0, left: 0, borderTop: `${w}px solid ${c}`, borderLeft: `${w}px solid ${c}` })} />
        <span style={cn({ top: 0, right: 0, borderTop: `${w}px solid ${c}`, borderRight: `${w}px solid ${c}` })} />
        <span style={cn({ bottom: 0, left: 0, borderBottom: `${w}px solid ${c}`, borderLeft: `${w}px solid ${c}` })} />
        <span style={cn({ bottom: 0, right: 0, borderBottom: `${w}px solid ${c}`, borderRight: `${w}px solid ${c}` })} />
        <span style={{ fontFamily: "var(--font-display)", fontWeight: 400, fontSize: 21, color: "var(--bone-000)", lineHeight: 1 }}>NV</span>
      </div>
      <div>
        <div style={{ fontFamily: "var(--font-display)", fontWeight: 300, fontSize: 20, lineHeight: 0.95, textTransform: "uppercase", color: "var(--text)" }}>Narrativas<br />Visuales</div>
      </div>
    </div>
  );
}

/* ======================= SESSION VIEW ======================= */
function BarChart({ focus }) {
  const data = [{ l: "L1", v: 42 }, { l: "L2", v: 55 }, { l: "L3", v: 61 }, { l: "L4", v: 48 }, { l: "L5", v: 73 }, { l: "L6", v: 94 }];
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 18, height: 240, padding: "10px 6px" }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <div style={{ position: "relative", width: "100%", height: "100%", display: "flex", alignItems: "flex-end" }}>
            <div style={{
              width: "100%", height: `${d.v}%`, borderRadius: "2px 2px 0 0",
              background: focus && i === 5 ? "var(--accent)" : "var(--carbon-600)",
              transition: "background var(--dur) var(--ease)",
            }} />
            {focus && i === 5 ? (
              <span style={{ position: "absolute", top: -6, left: "50%", transform: "translateX(-50%)", fontFamily: "var(--font-text)", fontSize: 12, fontWeight: 700, color: "var(--accent)" }}>94%</span>
            ) : null}
          </div>
          <span style={{ fontFamily: "var(--font-text)", fontSize: 11, letterSpacing: "0.08em", color: focus && i === 5 ? "var(--accent)" : "var(--text-faint)" }}>{d.l}</span>
        </div>
      ))}
    </div>
  );
}

function SessionView({ week, tab, onTab, focus, onFocus, isDone, onToggleDone }) {
  return (
    <div style={{ flex: 1, overflowY: "auto", height: "100%" }}>
      {/* hero */}
      <div style={{ padding: "36px 44px 26px", borderBottom: "1px solid var(--border)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 18 }}>
          <Badge tone="focus" solid>{"Semana " + String(week.n).padStart(2, "0")}</Badge>
          <Badge tone="neutral">{week.part}</Badge>
        </div>
        <h1 style={{ fontFamily: "var(--font-display)", fontWeight: 300, fontSize: 60, lineHeight: 0.95, textTransform: "uppercase", color: "var(--text)", margin: "0 0 16px", maxWidth: 900 }}>{week.title}</h1>
        <p style={{ fontFamily: "var(--font-text)", fontSize: 19, lineHeight: 1.5, color: "var(--text-muted)", maxWidth: "60ch", margin: 0 }}>
          Apertura narrativa breve, práctica activa intensiva. Pasa de mostrar el dato a mover una decisión.
        </p>
        <div style={{ display: "flex", gap: 12, marginTop: 26 }}>
          <Button variant="primary" iconRight={<Ico n="arrow-right" s={16} />}>Empezar sesión</Button>
          <Button variant={isDone ? "secondary" : "ghost"} onClick={onToggleDone} iconLeft={<Ico n={isDone ? "check" : "circle"} s={16} />}>
            {isDone ? "Completada" : "Marcar completa"}
          </Button>
        </div>
      </div>

      {/* body */}
      <div style={{ padding: "28px 44px 60px" }}>
        <div style={{ marginBottom: 26 }}>
          <Tabs value={tab} onChange={onTab} tabs={[{ value: "sesion", label: "La sesión" }, { value: "caso", label: "Caso" }, { value: "entrega", label: "Entrega" }]} />
        </div>

        {tab === "sesion" ? (
          <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 26, alignItems: "start" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <FigureFrame index="FIG 05" caption="Rendimiento por lote — el lote 6 es el punto de decisión">
                <BarChart focus={focus} />
              </FigureFrame>
              <Callout tone="focus" title="El movimiento">
                Un solo cambio — todo a gris, una barra en citrón — convierte una tabla en una historia. El ojo va directo a la decisión.
              </Callout>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
              <Card title="Enfoca la toma" padding="var(--s-5)">
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
                  <span style={{ fontFamily: "var(--font-text)", fontSize: 14, color: "var(--text-muted)" }}>Resaltar el foco</span>
                  <NV.Switch checked={focus} onChange={onFocus} />
                </div>
                <div style={{ display: "flex", gap: 24 }}>
                  <Stat label="Rendimiento" value="94%" delta="+12 pts" emphasis={focus} />
                  <Stat label="Fuera de rango" value="3" delta="-40%" />
                </div>
              </Card>
              <Callout tone="ethics">
                Una escala truncada o un color engañoso puede subestimar un riesgo. La ética es el hilo conductor del curso.
              </Callout>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                <Tag>Storytelling with Data</Tag>
                <Tag>Preattentive</Tag>
                <Tag selected onClick={() => {}}>Foco</Tag>
              </div>
            </div>
          </div>
        ) : tab === "caso" ? (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
            {[
              { e: "Biorreactor", t: "Eficiencia bajo presión", d: "De 12 variables de proceso a la única que mueve el rendimiento." },
              { e: "Vida útil", t: "El lote que decide", d: "Una serie temporal que le dice a calidad cuándo actuar." },
              { e: "Inocuidad", t: "El riesgo invisible", d: "Cómo una visualización honesta evita una decisión equivocada." },
              { e: "Sensores", t: "Ruido vs señal", d: "Reducir mil puntos a la tendencia que importa." },
            ].map((c, i) => (
              <Card key={i} eyebrow={c.e} title={c.t} interactive framed={i === 0}>
                <p style={{ margin: 0, fontFamily: "var(--font-text)", fontSize: 15, lineHeight: 1.55, color: "var(--text-muted)" }}>{c.d}</p>
              </Card>
            ))}
          </div>
        ) : (
          <div style={{ maxWidth: 640, display: "flex", flexDirection: "column", gap: 20 }}>
            <Card title="Entrega de la semana">
              <p style={{ margin: "0 0 20px", fontFamily: "var(--font-text)", fontSize: 15, lineHeight: 1.55, color: "var(--text-muted)" }}>
                Sube un gráfico rediseñado: de la versión cruda a una toma con un solo foco. Máximo una lámina.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <NV.Input label="Título de la historia" placeholder="Una frase, no un tema" />
                <NV.Select label="Formato del ejercicio" options={["Análogo (papel)", "Colaborativo (1-2-4)", "Con IA generativa"]} />
                <NV.Checkbox label="Incluye una llamada a la acción explícita" checked onChange={() => {}} />
              </div>
              <div style={{ marginTop: 22, display: "flex", gap: 12 }}>
                <Button variant="primary">Enviar entrega</Button>
                <Button variant="ghost">Guardar borrador</Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { Sidebar, SessionView, WEEKS });
})();
