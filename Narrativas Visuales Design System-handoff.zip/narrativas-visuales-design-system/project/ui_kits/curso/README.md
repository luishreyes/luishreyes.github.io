# UI Kit — Course Hub

An interactive recreation of the **Narrativas Visuales** course platform: the learning surface students use across the 16-week elective.

## Files
- `index.html` — mountable, interactive hub. Composes DS primitives from the compiled bundle.
- `screens.jsx` — `Sidebar`, `SessionView`, and the `WEEKS` syllabus data.

## What it demonstrates
- **Week navigation** — left rail with the two course halves (Fundamentos / Presentación), per-week completion state, and the `ProgressTrack`.
- **Session view** — hero with tracked eyebrow badges + display headline, then three tabs (La sesión / Caso / Entrega).
- **Focus-vs-context interaction** — the `Switch` in "Enfoca la toma" recolors the chart and the headline `Stat` to citron, live-demonstrating the course's core principle.
- **Entrega form** — Input, Select, Checkbox, Button composed into a submission flow.

## Composition rule
Every control is a DS primitive (`Button`, `Card`, `Callout`, `Tabs`, `Stat`, `FigureFrame`, …). The kit adds only layout and the small `BarChart` demo — it never re-implements a primitive.

## Icons
Lucide via CDN (`lucide@latest`). See root readme → ICONOGRAPHY.
