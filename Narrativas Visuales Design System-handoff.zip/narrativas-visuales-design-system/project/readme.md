# Narrativas Visuales — Design System

A visual identity and component system for **Narrativas Visuales de Datos con IA Generativa**, a 16-week practical elective for chemical & food engineers. The course teaches students to move *from showing data to telling user-centered stories* — integrating Cole Nussbaumer Knaflic's *Storytelling with Data* (first half) and *Storytelling with You* (second half) with generative-AI tools (Google AI Studio, Claude, ChatGPT).

The system is deliberately **cinematic, not corporate/academic**: charcoal is the stage, bone white is the text and air, and a single citron-yellow accent marks the focus. That palette is not decoration — it *is* the pedagogy: everything is context (gray) until one thing becomes the focus (citron), exactly the Storytelling-with-Data discipline the course trains.

## Sources
- `uploads/Manual de identidad.pdf` — the "Luis H. Reyes · Fotografía" personal identity manual (v1.0, July 2026), the instructor's personal photography brand. Used as the **aesthetic seed**, not a spec to reproduce: its charcoal/bone/citron palette, Big Shoulders + Archivo typography, tracked-uppercase labels, and camera **viewfinder** framing motif are carried into the course system. Extracted text: `scraps/` (page renders unavailable — see Caveats).
- The course description supplied in the brief (rationale, format, ethics through-line).

The photography brand's actual logo (the **H-in-viewfinder** mark) is *personal* and is **not** reused as the course mark. Instead the course uses a plain **"Narrativas Visuales" wordmark** in Big Shoulders Display plus the generic **viewfinder corner-bracket device** (a shared visual motif, not the personal logo). No course logo file was provided; see ICONOGRAPHY.

---

## CONTENT FUNDAMENTALS
How copy is written in this system.

- **Language:** Spanish (Colombian, neutral). Technical but never stiff.
- **Person:** Second person / imperative to the student — *"Elige el gráfico correcto"*, *"Enfoca la toma"*. First person appears only as the brand's own voice in quotes (the photographer's *"…esa es la que busco"*).
- **Sentences:** Short and declarative. One idea per line. Cut every word that can be cut.
- **The recurring question:** the course's spine is *"La pregunta no es qué dicen los datos, sino qué decisión se va a tomar con ellos."* Copy should keep pointing at the **decision**, not the feature or the chart.
- **Photographic metaphor:** framing, focus, exposure, "la toma" (the shot), "revelar". A figure worth showing is *the shot*.
- **Casing:** Eyebrows/labels are UPPERCASE with wide tracking (`S E M A N A   0 7`). Display headlines are uppercase in hero contexts, sentence case elsewhere. Body is sentence case.
- **Tone words:** deliberate, precise, honest. **Ethics is a permanent through-line** — copy names the risk of a misleading visualization plainly (see `Callout tone="ethics"`).
- **No emoji.** No exclamation-heavy marketing voice. No academic hedging ("it could be argued that…"). No corporate filler ("leverage synergies").
- **Numbers:** always tabular figures; a single number can be a headline (`Stat`).

Example (on-voice):
> **SERIE — ESTUDIOS**
> El gráfico correcto
> Elige el tipo de gráfico por la decisión que habilita, no por costumbre.

---

## VISUAL FOUNDATIONS

**Color.** Three families. `--carbon-*` (charcoal, #0A0A0A base) is the stage and dominates ~70% of any surface. `--bone-*` (#E8E6E1) is text and air, ~20%. `--citron-*` (#C9C41C) is the single accent, ~10% — headlines, the mark, one link, the one data mark that matters. Never citron as a large fill; never citron beside another saturated color. One restrained warm signal, `--clay-000` (#C8623A), exists **only** for data negatives that must be distinguished from focus. Semantic roles map to the SWD model: `--focus` (citron) vs `--context` (gray).

**Type.** Display = **Big Shoulders Display** (condensed, cinematic; weights 200–500, tracking near 0 or slightly negative). Text/labels = **Archivo** (400–700). Labels use the signature wide-tracked uppercase (`--tracking-label: 0.28em`). Because the display face is condensed, headlines go large (up to 128px hero). Hierarchy comes from **size + weight contrast, not color**.

**Spacing.** 4px base unit (`--s-1`…`--s-24`). A "safe area" token (`--safe-area`) echoes the manual's viewfinder margin: nothing enters the frame's reserved edge.

**Backgrounds.** Flat charcoal — no gradients as decoration. The only gradient is `--veil` / `--veil-strong`, a black protection veil laid over photography (~40%) so bone text and the citron mark stay legible, straight from the manual. Optional low-opacity grain (`--grain-opacity`) for texture; never busy patterns.

**Imagery.** Warm-toned, high-contrast, often near-monochrome — in the spirit of the source brand's black-and-white photography (*"the version of each scene that only appears when you remove the color"*). Always darken before overlaying text/logo.

**Corner radii.** Sharp and photographic. `--r-1: 2px` / `--r-2: 4px` are the norm; `--r-full` is reserved for status dots and avatars only. Nothing is pill-shaped by default.

**Borders.** Hairline bone at low alpha (`--line` = rgba(232,230,225,0.16)); `--border-strong` for emphasis; `--border-focus` is citron. The **viewfinder frame** (four citron corner brackets) is the system's signature border treatment — see `Card framed` and `FigureFrame`.

**Shadows.** Restrained. Depth comes from *raised charcoal* surfaces (`--carbon-900` over `--carbon-1000`), not glow. `--shadow-2` / `--shadow-pop` exist for overlays only.

**Cards.** Carbon surface (`--surface`), 1px hairline border, 4px radius, generous padding. No colored left-border-only cards, no drop shadow by default. The `framed` variant adds citron viewfinder brackets to spotlight the one card that holds the focus.

**Motion.** Deliberate and shutter-like — `--ease: cubic-bezier(0.22,0.61,0.36,1)`, `--dur: 220ms`. Fades and short slides; **no bounce, no spring**. Respect `prefers-reduced-motion`.

**Hover states.** Primary button lightens to `--accent-hover`; secondary gains a stronger border + faint bone wash; ghost lifts from muted to full bone; interactive cards lift 2px and strengthen their border. **No color-shift to unrelated hues.**

**Press states.** Buttons translate down 1px (a physical "click"), no scale-bounce.

**Focus ring.** Citron, offset from the carbon background (`--ring`).

**Transparency & blur.** Used sparingly — the protection veil over images, faint bone washes on hover. No frosted-glass everywhere.

**Layout rules.** Left rail is fixed; content scrolls. Respect the safe area. One primary action per view. One focus (citron) per view.

---

## ICONOGRAPHY
- **System:** [Lucide](https://lucide.dev) via CDN (`lucide@latest`), used at 16–18px, 2px stroke. Lucide's thin, geometric, open-stroke line style matches the brand's fine/condensed character. **This is a substitution** — the source manual defines no icon set; Lucide was chosen as the closest fit. Swap freely if you prefer another line set of the same weight.
- **Delivery:** linked from CDN, referenced as `<i data-lucide="arrow-right"></i>` then `lucide.createIcons()`. No icon font or SVG sprite is bundled.
- **The viewfinder brackets** (four corner marks) are a **brand device**, not an icon — rendered in CSS/JSX (`Card framed`, `FigureFrame`, the wordmark). Never redraw them as an image.
- **Emoji:** never used.
- **Unicode as glyphs:** minimal — a checkmark ✓ for completion, arrow ▾/▴ for stat deltas. Prefer Lucide for anything richer.
- No brand logo files were provided; the wordmark is set in live type. If you have a course logo, drop it in `assets/` and update the wordmark usages.

---

## Index / Manifest

**Root**
- `styles.css` — the single entry point consumers link (`@import` lines only).
- `thumbnail.html` — homepage tile.
- `readme.md` — this file. `SKILL.md` — Agent-Skills wrapper.

**Tokens** (`tokens/`, all reached via `styles.css`)
- `fonts.css` — Big Shoulders Display + Archivo (Google Fonts CDN — see Caveats).
- `colors.css` — carbon / bone / citron scales + clay signal + semantic aliases.
- `typography.css` — font families, weights, sizes, tracking.
- `spacing.css` — 4px scale, safe area, container widths.
- `effects.css` — radii, borders, shadows, veil, motion, and the `.nv-frame` / `.nv-label` utilities.
- `base.css` — optional element defaults (`.nv` / `.nv-root`).

**Components** (`components/`) — namespace `window.NarrativasVisualesDesignSystem_47c612`
- `core/` — **Button**, **IconButton**, **Badge**, **Tag**
- `forms/` — **Input**, **Select**, **Checkbox**, **Radio**, **Switch**
- `surfaces/` — **Card**, **Callout**, **Tabs**
- `data/` — **Stat**, **FigureFrame**, **ProgressTrack**

**UI kits** (`ui_kits/`)
- `curso/` — interactive Course Hub (week nav, session view, entrega form).

**Foundations** (`guidelines/`) — specimen cards for the Design System tab (Colors, Type, Spacing, Brand).

### Intentional additions
Built from brand guidelines only (no source component library), so a standard set was authored, trimmed to the course's needs:
- **FigureFrame** — the signature viewfinder device around a chart/figure; the most brand-specific primitive.
- **Stat** — a single number as a headline (data storytelling).
- **ProgressTrack** — the 16-week course arc.
- **Callout** with an `ethics` tone — supports the course's permanent ethics-in-data through-line.

---

## Caveats
- **Fonts load via Google Fonts CDN**, not self-hosted binaries. Both faces (Big Shoulders Display, Archivo) are the exact families from the manual, so this is a delivery choice, not a substitution — but for offline/self-hosted use, replace the `@import` in `tokens/fonts.css` with local `@font-face` rules + `.woff2` files.
- **PDF page renders unavailable** — the sandbox could not rasterize the manual's pages; the system is built from the manual's full extracted text (palette hexes, type specs, motif descriptions), which is complete and precise.
- **Icons are Lucide (substitution)** — the manual specifies no icon set.
- **No logo file** — course wordmark is live type; viewfinder is a CSS device.
