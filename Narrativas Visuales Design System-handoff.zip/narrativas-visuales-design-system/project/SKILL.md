---
name: narrativas-visuales-design
description: Use this skill to generate well-branded interfaces and assets for Narrativas Visuales (the "Narrativas Visuales de Datos con IA Generativa" course), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. A cinematic charcoal/bone/citron identity built on a Storytelling-with-Data focus-vs-context principle.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation
- **Entry point:** link `styles.css` (it `@import`s every token + font file).
- **The rule of the brand:** charcoal is the stage (~70%), bone is text/air (~20%), citron is the single focus accent (~10%). Everything is gray context until one thing becomes the focus. Never citron as a big fill, never beside another saturated color.
- **Type:** Big Shoulders Display (condensed, cinematic headlines) + Archivo (body/labels). Labels are UPPERCASE + wide-tracked.
- **Signature device:** the camera **viewfinder** corner-brackets — see `components/surfaces/Card.jsx` (`framed`) and `components/data/FigureFrame.jsx`.
- **Components** mount from `window.NarrativasVisualesDesignSystem_47c612` after loading `_ds_bundle.js`. Each has a `.prompt.md` with usage.
- **Voice:** Spanish, second person, short sentences, decision-focused, ethics as a through-line. No emoji.
