Carbon surface panel — the workhorse container. `framed` adds the signature citron viewfinder brackets; use it to mark the one card that holds the focus.

```jsx
<Card eyebrow="Semana 03" title="El gráfico correcto">
  <p>Elige el tipo de gráfico por la decisión que habilita, no por costumbre.</p>
</Card>

<Card framed interactive title="Caso de estudio">…</Card>
```

`interactive` adds hover lift. Keep `framed` rare — it's a spotlight.
