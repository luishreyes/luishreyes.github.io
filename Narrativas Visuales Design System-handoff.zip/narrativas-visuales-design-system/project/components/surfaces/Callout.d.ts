import * as React from "react";

/** Bordered aside for notes, key points, and the ethics through-line. */
export interface CalloutProps {
  children: React.ReactNode;
  /** @default "note" */
  tone?: "note" | "focus" | "ethics";
  /** Override the auto label. */
  title?: string;
}
export declare function Callout(props: CalloutProps): JSX.Element;
