Underline tab navigation, citron active rule.

```jsx
<Tabs value={t} onChange={setT}
  tabs={["Fundamentos", "Presentación", "Con IA"]} />
```
