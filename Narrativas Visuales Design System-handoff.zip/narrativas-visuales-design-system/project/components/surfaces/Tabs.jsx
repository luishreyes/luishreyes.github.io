import React from "react";

/** Tabs — underline-style nav. Active tab gets a citron rule. */
export function Tabs({ tabs = [], value, onChange }) {
  return (
    <div style={{ display: "flex", gap: "var(--s-6)", borderBottom: "var(--bw) solid var(--border)" }}>
      {tabs.map((t) => {
        const val = typeof t === "string" ? t : t.value;
        const lab = typeof t === "string" ? t : t.label;
        const active = val === value;
        return (
          <button
            key={val}
            onClick={() => onChange && onChange(val)}
            style={{
              background: "none", border: "none", cursor: "pointer",
              padding: "0 0 var(--s-3)", marginBottom: "-1px",
              fontFamily: "var(--font-text)", fontSize: "var(--fs-body-s)", fontWeight: "var(--w-semibold)",
              letterSpacing: "var(--tracking-eyebrow)", textTransform: "uppercase",
              color: active ? "var(--text)" : "var(--text-faint)",
              borderBottom: `var(--bw-2) solid ${active ? "var(--accent)" : "transparent"}`,
              transition: "color var(--dur-fast) var(--ease)",
            }}
          >{lab}</button>
        );
      })}
    </div>
  );
}
