Bordered aside. The `ethics` tone carries the course's permanent ethics-in-data through-line.

```jsx
<Callout tone="ethics">Una visualización engañosa lleva a decisiones equivocadas.</Callout>
<Callout tone="focus" title="La pregunta">¿Qué decisión se tomará con estos datos?</Callout>
```

Tones: `note`, `focus` (citron), `ethics` (clay).
