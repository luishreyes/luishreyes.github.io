import * as React from "react";

/**
 * Carbon surface panel. `framed` draws the citron viewfinder corner-brackets.
 * @startingPoint section="Surfaces" subtitle="Carbon panel with viewfinder frame" viewport="700x260"
 */
export interface CardProps {
  children: React.ReactNode;
  /** Uppercase tracked citron eyebrow. */
  eyebrow?: string;
  /** Display-type heading. */
  title?: string;
  /** Draw the citron viewfinder corner brackets. @default false */
  framed?: boolean;
  /** Lift + border on hover. @default false */
  interactive?: boolean;
  padding?: string;
  onClick?: () => void;
}
export declare function Card(props: CardProps): JSX.Element;
