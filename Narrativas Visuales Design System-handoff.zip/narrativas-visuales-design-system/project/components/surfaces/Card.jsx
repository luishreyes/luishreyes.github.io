import React from "react";

/**
 * Card — carbon surface panel. Optional eyebrow label + viewfinder frame.
 * The `framed` prop draws the citron viewfinder brackets (the brand device).
 */
export function Card({
  children,
  eyebrow = null,
  title = null,
  framed = false,
  interactive = false,
  padding = "var(--s-6)",
  onClick = null,
}) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: "relative",
        background: "var(--surface)",
        border: `var(--bw) solid ${interactive && hover ? "var(--border-strong)" : "var(--border)"}`,
        borderRadius: "var(--r-2)",
        padding,
        cursor: interactive ? "pointer" : "default",
        transition: "border-color var(--dur) var(--ease), transform var(--dur) var(--ease)",
        transform: interactive && hover ? "translateY(-2px)" : "none",
      }}
    >
      {framed ? <FrameCorners /> : null}
      {eyebrow ? (
        <div style={{
          fontFamily: "var(--font-text)", fontSize: "var(--fs-label-s)", fontWeight: "var(--w-semibold)",
          letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--accent)",
          marginBottom: "var(--s-3)",
        }}>{eyebrow}</div>
      ) : null}
      {title ? (
        <h3 style={{
          fontFamily: "var(--font-display)", fontWeight: "var(--w-light)", fontSize: "var(--fs-title)",
          lineHeight: "var(--lh-title)", color: "var(--text)", margin: "0 0 var(--s-3)",
        }}>{title}</h3>
      ) : null}
      {children}
    </div>
  );
}

function FrameCorners() {
  const arm = 18, w = 2, inset = 9, c = "var(--accent)";
  const base = { position: "absolute", width: arm, height: arm, pointerEvents: "none" };
  return (
    <>
      <span style={{ ...base, top: inset, left: inset, borderTop: `${w}px solid ${c}`, borderLeft: `${w}px solid ${c}` }} />
      <span style={{ ...base, top: inset, right: inset, borderTop: `${w}px solid ${c}`, borderRight: `${w}px solid ${c}` }} />
      <span style={{ ...base, bottom: inset, left: inset, borderBottom: `${w}px solid ${c}`, borderLeft: `${w}px solid ${c}` }} />
      <span style={{ ...base, bottom: inset, right: inset, borderBottom: `${w}px solid ${c}`, borderRight: `${w}px solid ${c}` }} />
    </>
  );
}
