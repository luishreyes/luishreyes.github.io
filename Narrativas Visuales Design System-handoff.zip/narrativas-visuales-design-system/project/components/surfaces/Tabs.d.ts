import * as React from "react";

/** Underline tab nav. Tabs are strings or {value,label}. */
export interface TabsProps {
  tabs: Array<string | { value: string; label: string }>;
  value: string;
  onChange?: (value: string) => void;
}
export declare function Tabs(props: TabsProps): JSX.Element;
