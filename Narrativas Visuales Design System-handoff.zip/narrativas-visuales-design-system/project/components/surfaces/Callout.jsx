import React from "react";

/**
 * Callout — bordered aside for notes, ethics warnings, tips.
 * Left rule in the tone color; used for the course's ethics through-line.
 */
export function Callout({ children, tone = "note", title = null }) {
  const tones = {
    note:  { rule: "var(--border-strong)", label: "var(--text-faint)", labelText: "Nota" },
    focus: { rule: "var(--accent)", label: "var(--accent)", labelText: "Clave" },
    ethics:{ rule: "var(--signal-negative)", label: "var(--signal-negative)", labelText: "Ética" },
  }[tone];
  return (
    <div style={{
      display: "flex", gap: "var(--s-4)",
      background: "var(--surface-2)",
      borderLeft: `var(--bw-2) solid ${tones.rule}`,
      borderRadius: "0 var(--r-2) var(--r-2) 0",
      padding: "var(--s-4) var(--s-5)",
    }}>
      <div style={{ flex: 1 }}>
        <div style={{
          fontFamily: "var(--font-text)", fontSize: "var(--fs-label-s)", fontWeight: "var(--w-semibold)",
          letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: tones.label,
          marginBottom: "var(--s-2)",
        }}>{title || tones.labelText}</div>
        <div style={{ fontFamily: "var(--font-text)", fontSize: "var(--fs-body)", lineHeight: "var(--lh-body)", color: "var(--text-muted)" }}>
          {children}
        </div>
      </div>
    </div>
  );
}
