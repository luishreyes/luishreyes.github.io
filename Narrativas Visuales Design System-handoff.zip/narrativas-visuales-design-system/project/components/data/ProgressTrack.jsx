import React from "react";

/**
 * ProgressTrack — a segmented track for the 16-week course arc.
 * Filled = completed (citron), current = outlined citron, rest = context.
 */
export function ProgressTrack({ total = 16, current = 1, label = null }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--s-3)", width: "100%" }}>
      {label ? (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <span style={{
            fontFamily: "var(--font-text)", fontSize: "var(--fs-label-s)", fontWeight: "var(--w-semibold)",
            letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-faint)",
          }}>{label}</span>
          <span style={{
            fontFamily: "var(--font-display)", fontSize: "var(--fs-subtitle)", fontWeight: "var(--w-medium)",
            color: "var(--accent)", fontVariantNumeric: "tabular-nums",
          }}>{String(current).padStart(2, "0")} / {total}</span>
        </div>
      ) : null}
      <div style={{ display: "flex", gap: "3px" }}>
        {Array.from({ length: total }).map((_, i) => {
          const n = i + 1;
          const done = n < current;
          const now = n === current;
          return (
            <div key={i} style={{
              flex: 1, height: 6, borderRadius: "var(--r-1)",
              background: done ? "var(--accent)" : now ? "transparent" : "var(--carbon-700)",
              border: now ? "var(--bw) solid var(--accent)" : "none",
              boxSizing: "border-box",
              transition: "background var(--dur) var(--ease)",
            }} />
          );
        })}
      </div>
    </div>
  );
}
