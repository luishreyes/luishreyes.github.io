import * as React from "react";

/** Segmented progress track for the 16-week course arc. */
export interface ProgressTrackProps {
  /** Total segments. @default 16 */
  total?: number;
  /** 1-based current segment. @default 1 */
  current?: number;
  label?: string;
}
export declare function ProgressTrack(props: ProgressTrackProps): JSX.Element;
