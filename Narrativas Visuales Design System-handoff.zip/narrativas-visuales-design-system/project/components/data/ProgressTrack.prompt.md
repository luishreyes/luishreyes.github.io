Segmented progress track for the course arc. Filled = done (citron), current = outlined, rest = context gray.

```jsx
<ProgressTrack total={16} current={7} label="Progreso del curso" />
```
