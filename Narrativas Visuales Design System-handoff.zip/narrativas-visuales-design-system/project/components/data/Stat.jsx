import React from "react";

/**
 * Stat — a single number that carries a story. Display type, tabular figures.
 * `emphasis` makes the value citron (the focus); otherwise it stays bone.
 */
export function Stat({ value, label = null, delta = null, deltaTone = "auto", emphasis = false, align = "left" }) {
  let tone = deltaTone;
  if (delta != null && deltaTone === "auto") {
    const n = parseFloat(String(delta).replace(/[^0-9.\-]/g, ""));
    tone = n < 0 ? "down" : "up";
  }
  const deltaColor = tone === "down" ? "var(--signal-negative)" : "var(--accent)";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "6px", textAlign: align, alignItems: align === "center" ? "center" : "flex-start" }}>
      {label ? (
        <span style={{
          fontFamily: "var(--font-text)", fontSize: "var(--fs-label-s)", fontWeight: "var(--w-semibold)",
          letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-faint)",
        }}>{label}</span>
      ) : null}
      <span style={{
        fontFamily: "var(--font-display)", fontWeight: "var(--w-light)", fontSize: "var(--fs-display-m)",
        lineHeight: 0.95, color: emphasis ? "var(--accent)" : "var(--text)",
        fontFeatureSettings: "var(--fnum)", fontVariantNumeric: "tabular-nums",
      }}>{value}</span>
      {delta != null ? (
        <span style={{
          fontFamily: "var(--font-text)", fontSize: "var(--fs-body-s)", fontWeight: "var(--w-semibold)",
          color: deltaColor, fontFeatureSettings: "var(--fnum)",
        }}>{tone === "down" ? "▾" : "▴"} {delta}</span>
      ) : null}
    </div>
  );
}
