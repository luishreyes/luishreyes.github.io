import * as React from "react";

/**
 * The signature viewfinder device: frames a chart/image as "the shot" with
 * corner brackets and a tracked caption.
 * @startingPoint section="Data" subtitle="Viewfinder-framed figure" viewport="700x420"
 */
export interface FigureFrameProps {
  /** The chart, image, or <img> to frame. */
  children: React.ReactNode;
  /** Tracked uppercase caption. */
  caption?: string;
  /** Figure index / label, e.g. "FIG 03". */
  index?: string;
  /** Show the viewfinder corner brackets. @default true */
  corners?: boolean;
  /** Bracket color (CSS var or hex). @default citron */
  cornerColor?: string;
}
export declare function FigureFrame(props: FigureFrameProps): JSX.Element;
