import * as React from "react";

/**
 * A single number that carries a story — display type, tabular figures.
 * @startingPoint section="Data" subtitle="Headline metric with delta" viewport="700x180"
 */
export interface StatProps {
  /** The number, pre-formatted (e.g. "23.8M", "94%"). */
  value: React.ReactNode;
  label?: string;
  /** Change indicator, e.g. "+12%" or "-3.4 pts". */
  delta?: string;
  /** Force the delta arrow color; "auto" reads the sign. @default "auto" */
  deltaTone?: "auto" | "up" | "down";
  /** Make the value citron (the focus). @default false */
  emphasis?: boolean;
  align?: "left" | "center";
}
export declare function Stat(props: StatProps): JSX.Element;
