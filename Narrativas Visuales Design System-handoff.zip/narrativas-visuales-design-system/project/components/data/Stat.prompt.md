A single number that carries the story. Use `emphasis` on the one metric that is the point; leave the rest bone so they read as context.

```jsx
<Stat label="Rendimiento del biorreactor" value="94%" delta="+12 pts" emphasis />
<Stat label="Lotes fuera de rango" value="3" delta="-40%" />
```

`delta` auto-colors by sign (citron up / clay down). Values are pre-formatted strings — the component only does tabular figures.
