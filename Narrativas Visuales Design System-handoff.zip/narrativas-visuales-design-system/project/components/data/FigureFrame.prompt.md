The signature brand device. Wraps a chart or image in camera-viewfinder brackets so the figure reads as "the shot" — the framed focus of the story.

```jsx
<FigureFrame index="FIG 03" caption="Vida útil por lote — 2025">
  <img src="chart.png" style={{ width: "100%", display: "block" }} />
</FigureFrame>
```

Set `corners={false}` for a plain framed figure. Keep the citron brackets for the figure that is the point of the slide.
