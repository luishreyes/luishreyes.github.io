import React from "react";

/**
 * FigureFrame — the signature device. Wraps a chart or image in the camera
 * viewfinder brackets, with an optional tracked caption + focus annotation.
 * This is how a figure becomes "the shot" in Narrativas Visuales.
 */
export function FigureFrame({ children, caption = null, index = null, corners = true, cornerColor = "var(--accent)" }) {
  const arm = 22, w = 2, inset = 0;
  const base = { position: "absolute", width: arm, height: arm, pointerEvents: "none", zIndex: 2 };
  return (
    <figure style={{ margin: 0, display: "flex", flexDirection: "column", gap: "var(--s-3)" }}>
      <div style={{
        position: "relative", padding: "var(--s-4)",
        background: "var(--carbon-950)",
        border: "var(--bw) solid var(--border)",
        borderRadius: "var(--r-2)",
      }}>
        {corners ? (
          <>
            <span style={{ ...base, top: inset, left: inset, borderTop: `${w}px solid ${cornerColor}`, borderLeft: `${w}px solid ${cornerColor}` }} />
            <span style={{ ...base, top: inset, right: inset, borderTop: `${w}px solid ${cornerColor}`, borderRight: `${w}px solid ${cornerColor}` }} />
            <span style={{ ...base, bottom: inset, left: inset, borderBottom: `${w}px solid ${cornerColor}`, borderLeft: `${w}px solid ${cornerColor}` }} />
            <span style={{ ...base, bottom: inset, right: inset, borderBottom: `${w}px solid ${cornerColor}`, borderRight: `${w}px solid ${cornerColor}` }} />
          </>
        ) : null}
        {children}
      </div>
      {caption ? (
        <figcaption style={{ display: "flex", alignItems: "baseline", gap: "var(--s-3)" }}>
          {index != null ? (
            <span style={{
              fontFamily: "var(--font-text)", fontSize: "var(--fs-label-s)", fontWeight: "var(--w-bold)",
              letterSpacing: "var(--tracking-wide)", color: "var(--accent)", flexShrink: 0,
            }}>{index}</span>
          ) : null}
          <span style={{
            fontFamily: "var(--font-text)", fontSize: "var(--fs-caption)", letterSpacing: "var(--tracking-wide)",
            textTransform: "uppercase", color: "var(--text-faint)", lineHeight: 1.5,
          }}>{caption}</span>
        </figcaption>
      ) : null}
    </figure>
  );
}
