Small uppercase status or counter chip.

```jsx
<Badge tone="focus" solid>Semana 07</Badge>
<Badge tone="neutral">Análogo</Badge>
```

Tones: `neutral`, `focus` (citron), `negative` (clay). `solid` fills it.
