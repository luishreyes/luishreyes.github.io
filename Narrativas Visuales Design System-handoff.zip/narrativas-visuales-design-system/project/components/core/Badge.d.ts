import * as React from "react";

/** Small uppercase status/counter chip. */
export interface BadgeProps {
  children: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "focus" | "negative";
  /** Filled instead of outlined. @default false */
  solid?: boolean;
}
export declare function Badge(props: BadgeProps): JSX.Element;
