Cinematic call-to-action. Use for the single most important action in a view — primary in citron, everything else secondary/ghost so it recedes.

```jsx
<Button variant="primary" size="lg">Ver el caso</Button>
<Button variant="secondary">Descargar</Button>
<Button variant="ghost" size="sm">Cancelar</Button>
```

Variants: `primary` (citron fill — the focus), `secondary` (bone outline), `ghost` (text), `danger` (clay outline). Sizes `sm | md | lg`. Text is uppercase + tracked by design; pass `iconLeft`/`iconRight` for Lucide glyphs. Keep one primary per view.
