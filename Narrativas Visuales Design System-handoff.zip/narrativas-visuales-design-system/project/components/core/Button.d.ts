import * as React from "react";

/**
 * Editorial call-to-action for Narrativas Visuales — uppercase, tracked, sharp corners.
 * @startingPoint section="Core" subtitle="Cinematic CTA with citron primary" viewport="700x160"
 */
export interface ButtonProps {
  children: React.ReactNode;
  /** Visual weight. @default "primary" */
  variant?: "primary" | "secondary" | "ghost" | "danger";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Fill the container width. @default false */
  block?: boolean;
  disabled?: boolean;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  /** Render as another element (e.g. "a"). @default "button" */
  as?: keyof JSX.IntrinsicElements;
  onClick?: (e: React.MouseEvent) => void;
}
export declare function Button(props: ButtonProps): JSX.Element;
