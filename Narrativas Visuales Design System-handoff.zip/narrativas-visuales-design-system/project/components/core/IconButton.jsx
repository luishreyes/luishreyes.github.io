import React from "react";

/**
 * IconButton — square, sharp icon-only control. Pass a Lucide (or any) glyph.
 */
export function IconButton({
  children,
  variant = "ghost",
  size = "md",
  disabled = false,
  "aria-label": ariaLabel,
  ...rest
}) {
  const dim = { sm: 30, md: 38, lg: 46 }[size];
  const [hover, setHover] = React.useState(false);

  const variants = {
    solid: { background: "var(--accent)", color: "var(--text-on-accent)", border: "none" },
    outline: { background: "transparent", color: "var(--text)", border: "var(--bw) solid var(--border-strong)" },
    ghost: { background: "transparent", color: "var(--text-muted)", border: "var(--bw) solid transparent" },
  };
  const hoverStyle = !disabled && hover ? {
    solid: { background: "var(--accent-hover)" },
    outline: { borderColor: "var(--text)", background: "rgba(232,230,225,0.04)" },
    ghost: { color: "var(--text)", background: "rgba(232,230,225,0.05)" },
  }[variant] : {};

  return (
    <button
      aria-label={ariaLabel}
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: dim, height: dim,
        borderRadius: "var(--r-1)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.4 : 1,
        transition: "all var(--dur-fast) var(--ease)",
        ...variants[variant],
        ...hoverStyle,
      }}
      {...rest}
    >
      {children}
    </button>
  );
}
