import React from "react";

/**
 * Button — Narrativas Visuales
 * Editorial, cinematic CTA. Uppercase + tracked, sharp corners.
 * Primary = citron on carbon (the focus). Others recede.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  block = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  ...rest
}) {
  const Tag = as;

  const sizes = {
    sm: { padding: "8px 16px", fontSize: "11px", gap: "8px" },
    md: { padding: "12px 22px", fontSize: "12.5px", gap: "9px" },
    lg: { padding: "16px 30px", fontSize: "14px", gap: "11px" },
  };

  const base = {
    display: block ? "flex" : "inline-flex",
    width: block ? "100%" : "auto",
    alignItems: "center",
    justifyContent: "center",
    ...sizes[size],
    fontFamily: "var(--font-text)",
    fontWeight: "var(--w-semibold)",
    letterSpacing: "var(--tracking-eyebrow)",
    textTransform: "uppercase",
    lineHeight: 1,
    border: "var(--bw) solid transparent",
    borderRadius: "var(--r-1)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    transition: "background var(--dur-fast) var(--ease), color var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease)",
    whiteSpace: "nowrap",
    userSelect: "none",
  };

  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--text-on-accent)",
    },
    secondary: {
      background: "transparent",
      color: "var(--text)",
      borderColor: "var(--border-strong)",
    },
    ghost: {
      background: "transparent",
      color: "var(--text-muted)",
    },
    danger: {
      background: "transparent",
      color: "var(--signal-negative)",
      borderColor: "var(--signal-negative)",
    },
  };

  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);

  const hoverStyle = !disabled && hover ? {
    primary: { background: "var(--accent-hover)" },
    secondary: { borderColor: "var(--text)", background: "rgba(232,230,225,0.04)" },
    ghost: { color: "var(--text)" },
    danger: { background: "var(--clay-900)" },
  }[variant] : {};

  const activeStyle = !disabled && active ? { transform: "translateY(1px)" } : {};

  return (
    <Tag
      style={{ ...base, ...variants[variant], ...hoverStyle, ...activeStyle }}
      disabled={as === "button" ? disabled : undefined}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      {...rest}
    >
      {iconLeft ? <span style={{ display: "inline-flex" }}>{iconLeft}</span> : null}
      {children}
      {iconRight ? <span style={{ display: "inline-flex" }}>{iconRight}</span> : null}
    </Tag>
  );
}
