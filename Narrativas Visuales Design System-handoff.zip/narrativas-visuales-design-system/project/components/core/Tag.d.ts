import * as React from "react";

/** Selectable / dismissible topic tag. */
export interface TagProps {
  children: React.ReactNode;
  selected?: boolean;
  onClick?: () => void;
  /** Show an × remove control. */
  onRemove?: () => void;
}
export declare function Tag(props: TagProps): JSX.Element;
