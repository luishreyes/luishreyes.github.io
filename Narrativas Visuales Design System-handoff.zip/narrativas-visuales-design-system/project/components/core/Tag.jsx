import React from "react";

/**
 * Tag — dismissible/selectable topic tag. Lower-contrast than Badge, sentence case.
 */
export function Tag({ children, selected = false, onRemove = null, onClick = null }) {
  const [hover, setHover] = React.useState(false);
  return (
    <span
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "6px",
        padding: "5px 10px",
        fontFamily: "var(--font-text)",
        fontSize: "var(--fs-body-s)",
        fontWeight: "var(--w-medium)",
        lineHeight: 1.2,
        borderRadius: "var(--r-2)",
        cursor: onClick ? "pointer" : "default",
        border: `var(--bw) solid ${selected ? "var(--border-focus)" : "var(--border)"}`,
        background: selected ? "var(--citron-900)" : (hover && onClick ? "var(--surface-hover)" : "var(--surface)"),
        color: selected ? "var(--accent)" : "var(--text-muted)",
        transition: "all var(--dur-fast) var(--ease)",
      }}
    >
      {children}
      {onRemove ? (
        <button
          aria-label="Quitar"
          onClick={(e) => { e.stopPropagation(); onRemove(); }}
          style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 14, height: 14, padding: 0, border: "none", background: "transparent",
            color: "currentColor", cursor: "pointer", opacity: 0.7, fontSize: "13px", lineHeight: 1,
          }}
        >×</button>
      ) : null}
    </span>
  );
}
