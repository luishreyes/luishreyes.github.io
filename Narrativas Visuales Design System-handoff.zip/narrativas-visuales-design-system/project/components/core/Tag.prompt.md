Selectable / removable topic tag — softer than Badge, sentence case.

```jsx
<Tag selected onClick={pick}>Storytelling</Tag>
<Tag onRemove={drop}>IA generativa</Tag>
```

`selected` gives it the citron state; pass `onRemove` for a × affordance.
