Square icon-only control for toolbars and tight spaces. Requires `aria-label`.

```jsx
<IconButton aria-label="Siguiente" variant="outline">
  <i data-lucide="arrow-right"></i>
</IconButton>
```

Variants: `solid` (citron), `outline`, `ghost`. Sizes `sm | md | lg`.
