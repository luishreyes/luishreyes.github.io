import React from "react";

/**
 * Badge — small status/counter pill. Sharp by default; citron accent optional.
 */
export function Badge({ children, tone = "neutral", solid = false }) {
  const tones = {
    neutral: { fg: "var(--text-muted)", bd: "var(--border-strong)", bg: "transparent", solidBg: "var(--carbon-700)", solidFg: "var(--text)" },
    focus:   { fg: "var(--accent)", bd: "var(--border-focus)", bg: "transparent", solidBg: "var(--accent)", solidFg: "var(--text-on-accent)" },
    negative:{ fg: "var(--signal-negative)", bd: "var(--signal-negative)", bg: "transparent", solidBg: "var(--signal-negative)", solidFg: "#150B06" },
  }[tone];

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "3px 9px",
        fontFamily: "var(--font-text)",
        fontSize: "var(--fs-label-s)",
        fontWeight: "var(--w-semibold)",
        letterSpacing: "var(--tracking-wide)",
        textTransform: "uppercase",
        lineHeight: 1.4,
        borderRadius: "var(--r-1)",
        border: solid ? "none" : `var(--bw) solid ${tones.bd}`,
        background: solid ? tones.solidBg : tones.bg,
        color: solid ? tones.solidFg : tones.fg,
        fontFeatureSettings: "var(--fnum)",
      }}
    >
      {children}
    </span>
  );
}
