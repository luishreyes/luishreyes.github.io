import React from "react";

/**
 * Input — text field with optional tracked label + hint. Sharp, carbon surface.
 */
export function Input({
  label = null,
  hint = null,
  error = null,
  value,
  onChange,
  placeholder = "",
  type = "text",
  disabled = false,
  iconLeft = null,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || React.useId();
  const borderColor = error ? "var(--signal-negative)" : focus ? "var(--border-focus)" : "var(--border-strong)";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "7px", width: "100%" }}>
      {label ? (
        <label htmlFor={inputId} style={{
          fontFamily: "var(--font-text)", fontSize: "var(--fs-label)", fontWeight: "var(--w-semibold)",
          letterSpacing: "var(--tracking-eyebrow)", textTransform: "uppercase", color: "var(--text-faint)",
        }}>{label}</label>
      ) : null}
      <div style={{
        display: "flex", alignItems: "center", gap: "10px",
        background: "var(--surface)",
        border: `var(--bw) solid ${borderColor}`,
        borderRadius: "var(--r-2)",
        padding: "0 14px",
        transition: "border-color var(--dur-fast) var(--ease)",
        opacity: disabled ? 0.5 : 1,
      }}>
        {iconLeft ? <span style={{ display: "inline-flex", color: "var(--text-faint)" }}>{iconLeft}</span> : null}
        <input
          id={inputId}
          type={type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex: 1, minWidth: 0,
            background: "transparent", border: "none", outline: "none",
            color: "var(--text)", fontFamily: "var(--font-text)", fontSize: "var(--fs-body)",
            padding: "12px 0", lineHeight: 1.3,
          }}
          {...rest}
        />
      </div>
      {error ? (
        <span style={{ fontFamily: "var(--font-text)", fontSize: "var(--fs-caption)", color: "var(--signal-negative)" }}>{error}</span>
      ) : hint ? (
        <span style={{ fontFamily: "var(--font-text)", fontSize: "var(--fs-caption)", color: "var(--text-faint)" }}>{hint}</span>
      ) : null}
    </div>
  );
}
