import * as React from "react";

/** Round radio button. Group by shared `name`. */
export interface RadioProps {
  checked?: boolean;
  onChange?: (value: string) => void;
  label?: React.ReactNode;
  name?: string;
  value?: string;
  disabled?: boolean;
  id?: string;
}
export declare function Radio(props: RadioProps): JSX.Element;
