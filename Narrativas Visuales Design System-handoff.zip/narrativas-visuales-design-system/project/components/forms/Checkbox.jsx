import React from "react";

/** Checkbox — square, citron when checked. */
export function Checkbox({ checked = false, onChange, label = null, disabled = false, id }) {
  const cbId = id || React.useId();
  return (
    <label htmlFor={cbId} style={{
      display: "inline-flex", alignItems: "center", gap: "10px",
      cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-text)", fontSize: "var(--fs-body)", color: "var(--text)",
    }}>
      <input id={cbId} type="checkbox" checked={checked} disabled={disabled}
        onChange={(e) => onChange && onChange(e.target.checked)}
        style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} />
      <span style={{
        width: 18, height: 18, flexShrink: 0,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        borderRadius: "var(--r-1)",
        border: `var(--bw-2) solid ${checked ? "var(--accent)" : "var(--border-strong)"}`,
        background: checked ? "var(--accent)" : "transparent",
        transition: "all var(--dur-fast) var(--ease)",
      }}>
        {checked ? (
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
            <path d="M2.5 6.2L5 8.7L9.5 3.5" stroke="var(--text-on-accent)" strokeWidth="2" strokeLinecap="square" />
          </svg>
        ) : null}
      </span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
