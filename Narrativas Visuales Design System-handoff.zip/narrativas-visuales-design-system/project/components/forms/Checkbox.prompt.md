Square checkbox, citron when checked.

```jsx
<Checkbox checked={ok} onChange={setOk} label="Incluye una llamada a la acción" />
```
