import React from "react";

/**
 * Select — native select styled to match Input. Tracked label optional.
 */
export function Select({ label = null, value, onChange, options = [], disabled = false, id, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const selId = id || React.useId();
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "7px", width: "100%" }}>
      {label ? (
        <label htmlFor={selId} style={{
          fontFamily: "var(--font-text)", fontSize: "var(--fs-label)", fontWeight: "var(--w-semibold)",
          letterSpacing: "var(--tracking-eyebrow)", textTransform: "uppercase", color: "var(--text-faint)",
        }}>{label}</label>
      ) : null}
      <div style={{ position: "relative", opacity: disabled ? 0.5 : 1 }}>
        <select
          id={selId}
          value={value}
          onChange={onChange}
          disabled={disabled}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            width: "100%", appearance: "none", WebkitAppearance: "none",
            background: "var(--surface)",
            border: `var(--bw) solid ${focus ? "var(--border-focus)" : "var(--border-strong)"}`,
            borderRadius: "var(--r-2)", color: "var(--text)",
            fontFamily: "var(--font-text)", fontSize: "var(--fs-body)",
            padding: "12px 40px 12px 14px", lineHeight: 1.3, cursor: "pointer",
            transition: "border-color var(--dur-fast) var(--ease)", outline: "none",
          }}
          {...rest}
        >
          {options.map((o) => {
            const val = typeof o === "string" ? o : o.value;
            const lab = typeof o === "string" ? o : o.label;
            return <option key={val} value={val} style={{ background: "var(--carbon-850)", color: "var(--text)" }}>{lab}</option>;
          })}
        </select>
        <span style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", pointerEvents: "none", color: "var(--text-faint)", fontSize: "12px" }}>▾</span>
      </div>
    </div>
  );
}
