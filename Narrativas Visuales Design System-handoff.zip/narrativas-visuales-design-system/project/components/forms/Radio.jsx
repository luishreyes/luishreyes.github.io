import React from "react";

/** Radio — round, citron dot when selected. */
export function Radio({ checked = false, onChange, label = null, name, value, disabled = false, id }) {
  const rId = id || React.useId();
  return (
    <label htmlFor={rId} style={{
      display: "inline-flex", alignItems: "center", gap: "10px",
      cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-text)", fontSize: "var(--fs-body)", color: "var(--text)",
    }}>
      <input id={rId} type="radio" name={name} value={value} checked={checked} disabled={disabled}
        onChange={() => onChange && onChange(value)}
        style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} />
      <span style={{
        width: 18, height: 18, flexShrink: 0, borderRadius: "var(--r-full)",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        border: `var(--bw-2) solid ${checked ? "var(--accent)" : "var(--border-strong)"}`,
        background: "transparent", transition: "all var(--dur-fast) var(--ease)",
      }}>
        {checked ? <span style={{ width: 8, height: 8, borderRadius: "var(--r-full)", background: "var(--accent)" }} /> : null}
      </span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
