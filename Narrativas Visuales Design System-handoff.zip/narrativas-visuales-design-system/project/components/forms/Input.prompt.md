Text field. Label is uppercase + tracked; focus ring is citron.

```jsx
<Input label="Título de la historia" placeholder="Una frase, no un tema" hint="Máx. 60 caracteres" />
<Input label="Correo" error="Formato inválido" value={v} onChange={set} />
```

Pass `iconLeft` for a leading glyph, `error` to switch to the negative state.
