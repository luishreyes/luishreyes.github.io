import * as React from "react";

/** Sliding on/off toggle. */
export interface SwitchProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  label?: React.ReactNode;
  disabled?: boolean;
  id?: string;
}
export declare function Switch(props: SwitchProps): JSX.Element;
