import * as React from "react";

/** Text field with optional tracked label, hint, and error state. */
export interface InputProps {
  label?: string;
  hint?: string;
  error?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  type?: string;
  disabled?: boolean;
  iconLeft?: React.ReactNode;
  id?: string;
}
export declare function Input(props: InputProps): JSX.Element;
