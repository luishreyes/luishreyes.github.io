import * as React from "react";

/** Styled native select. Options are strings or {value,label}. */
export interface SelectProps {
  label?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: Array<string | { value: string; label: string }>;
  disabled?: boolean;
  id?: string;
}
export declare function Select(props: SelectProps): JSX.Element;
