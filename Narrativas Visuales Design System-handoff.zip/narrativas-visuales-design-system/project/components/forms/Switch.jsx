import React from "react";

/** Switch — sliding toggle, citron track when on. */
export function Switch({ checked = false, onChange, label = null, disabled = false, id }) {
  const sId = id || React.useId();
  return (
    <label htmlFor={sId} style={{
      display: "inline-flex", alignItems: "center", gap: "12px",
      cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-text)", fontSize: "var(--fs-body)", color: "var(--text)",
    }}>
      <input id={sId} type="checkbox" checked={checked} disabled={disabled}
        onChange={(e) => onChange && onChange(e.target.checked)}
        style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} />
      <span style={{
        width: 40, height: 22, flexShrink: 0, borderRadius: "var(--r-full)",
        background: checked ? "var(--accent)" : "var(--carbon-700)",
        border: `var(--bw) solid ${checked ? "var(--accent)" : "var(--border-strong)"}`,
        position: "relative", transition: "all var(--dur) var(--ease)",
      }}>
        <span style={{
          position: "absolute", top: 2, left: checked ? 20 : 2,
          width: 16, height: 16, borderRadius: "var(--r-full)",
          background: checked ? "var(--text-on-accent)" : "var(--bone-300)",
          transition: "left var(--dur) var(--ease), background var(--dur) var(--ease)",
        }} />
      </span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
