Sliding toggle, citron track when on.

```jsx
<Switch checked={on} onChange={setOn} label="Mostrar datos crudos" />
```
