Round radio, citron dot when selected. Group with a shared `name`.

```jsx
<Radio name="fmt" value="analogo" checked={f==="analogo"} onChange={setF} label="Análogo" />
<Radio name="fmt" value="ia" checked={f==="ia"} onChange={setF} label="Con IA" />
```
