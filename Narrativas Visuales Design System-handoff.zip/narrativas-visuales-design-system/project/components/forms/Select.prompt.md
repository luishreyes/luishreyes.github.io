Styled native dropdown, matches Input.

```jsx
<Select label="Formato" value={fmt} onChange={setFmt}
  options={["Análogo", "Colaborativo", "Con IA"]} />
```

Options accept plain strings or `{value, label}`.
