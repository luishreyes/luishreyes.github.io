/* @ds-bundle: {"format":4,"namespace":"NarrativasVisualesDesignSystem_47c612","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"FigureFrame","sourcePath":"components/data/FigureFrame.jsx"},{"name":"ProgressTrack","sourcePath":"components/data/ProgressTrack.jsx"},{"name":"Stat","sourcePath":"components/data/Stat.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Callout","sourcePath":"components/surfaces/Callout.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"Tabs","sourcePath":"components/surfaces/Tabs.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"de1c847bd309","components/core/Button.jsx":"84efe0c42e5e","components/core/IconButton.jsx":"9f46dd40ec78","components/core/Tag.jsx":"76a20b6cc6c7","components/data/FigureFrame.jsx":"fe28be763f0b","components/data/ProgressTrack.jsx":"0182d75aaf58","components/data/Stat.jsx":"867252ccdb56","components/forms/Checkbox.jsx":"30bc2e070dc0","components/forms/Input.jsx":"fb949c2a1278","components/forms/Radio.jsx":"5a6b94f0fb11","components/forms/Select.jsx":"0d3e19b4e951","components/forms/Switch.jsx":"fed48e59e596","components/surfaces/Callout.jsx":"a4a360a63345","components/surfaces/Card.jsx":"57aacb4bb945","components/surfaces/Tabs.jsx":"eb1adc3af34f","ui_kits/curso/screens.jsx":"a728f81551a6"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NarrativasVisualesDesignSystem_47c612 = window.NarrativasVisualesDesignSystem_47c612 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
/**
 * Badge — small status/counter pill. Sharp by default; citron accent optional.
 */
function Badge({
  children,
  tone = "neutral",
  solid = false
}) {
  const tones = {
    neutral: {
      fg: "var(--text-muted)",
      bd: "var(--border-strong)",
      bg: "transparent",
      solidBg: "var(--carbon-700)",
      solidFg: "var(--text)"
    },
    focus: {
      fg: "var(--accent)",
      bd: "var(--border-focus)",
      bg: "transparent",
      solidBg: "var(--accent)",
      solidFg: "var(--text-on-accent)"
    },
    negative: {
      fg: "var(--signal-negative)",
      bd: "var(--signal-negative)",
      bg: "transparent",
      solidBg: "var(--signal-negative)",
      solidFg: "#150B06"
    }
  }[tone];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "3px 9px",
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label-s)",
      fontWeight: "var(--w-semibold)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      lineHeight: 1.4,
      borderRadius: "var(--r-1)",
      border: solid ? "none" : `var(--bw) solid ${tones.bd}`,
      background: solid ? tones.solidBg : tones.bg,
      color: solid ? tones.solidFg : tones.fg,
      fontFeatureSettings: "var(--fnum)"
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — Narrativas Visuales
 * Editorial, cinematic CTA. Uppercase + tracked, sharp corners.
 * Primary = citron on carbon (the focus). Others recede.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  block = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  ...rest
}) {
  const Tag = as;
  const sizes = {
    sm: {
      padding: "8px 16px",
      fontSize: "11px",
      gap: "8px"
    },
    md: {
      padding: "12px 22px",
      fontSize: "12.5px",
      gap: "9px"
    },
    lg: {
      padding: "16px 30px",
      fontSize: "14px",
      gap: "11px"
    }
  };
  const base = {
    display: block ? "flex" : "inline-flex",
    width: block ? "100%" : "auto",
    alignItems: "center",
    justifyContent: "center",
    ...sizes[size],
    fontFamily: "var(--font-text)",
    fontWeight: "var(--w-semibold)",
    letterSpacing: "var(--tracking-eyebrow)",
    textTransform: "uppercase",
    lineHeight: 1,
    border: "var(--bw) solid transparent",
    borderRadius: "var(--r-1)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    transition: "background var(--dur-fast) var(--ease), color var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease)",
    whiteSpace: "nowrap",
    userSelect: "none"
  };
  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--text-on-accent)"
    },
    secondary: {
      background: "transparent",
      color: "var(--text)",
      borderColor: "var(--border-strong)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-muted)"
    },
    danger: {
      background: "transparent",
      color: "var(--signal-negative)",
      borderColor: "var(--signal-negative)"
    }
  };
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const hoverStyle = !disabled && hover ? {
    primary: {
      background: "var(--accent-hover)"
    },
    secondary: {
      borderColor: "var(--text)",
      background: "rgba(232,230,225,0.04)"
    },
    ghost: {
      color: "var(--text)"
    },
    danger: {
      background: "var(--clay-900)"
    }
  }[variant] : {};
  const activeStyle = !disabled && active ? {
    transform: "translateY(1px)"
  } : {};
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      ...base,
      ...variants[variant],
      ...hoverStyle,
      ...activeStyle
    },
    disabled: as === "button" ? disabled : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false)
  }, rest), iconLeft ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, iconLeft) : null, children, iconRight ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, iconRight) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — square, sharp icon-only control. Pass a Lucide (or any) glyph.
 */
function IconButton({
  children,
  variant = "ghost",
  size = "md",
  disabled = false,
  "aria-label": ariaLabel,
  ...rest
}) {
  const dim = {
    sm: 30,
    md: 38,
    lg: 46
  }[size];
  const [hover, setHover] = React.useState(false);
  const variants = {
    solid: {
      background: "var(--accent)",
      color: "var(--text-on-accent)",
      border: "none"
    },
    outline: {
      background: "transparent",
      color: "var(--text)",
      border: "var(--bw) solid var(--border-strong)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-muted)",
      border: "var(--bw) solid transparent"
    }
  };
  const hoverStyle = !disabled && hover ? {
    solid: {
      background: "var(--accent-hover)"
    },
    outline: {
      borderColor: "var(--text)",
      background: "rgba(232,230,225,0.04)"
    },
    ghost: {
      color: "var(--text)",
      background: "rgba(232,230,225,0.05)"
    }
  }[variant] : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": ariaLabel,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: dim,
      height: dim,
      borderRadius: "var(--r-1)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      transition: "all var(--dur-fast) var(--ease)",
      ...variants[variant],
      ...hoverStyle
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
/**
 * Tag — dismissible/selectable topic tag. Lower-contrast than Badge, sentence case.
 */
function Tag({
  children,
  selected = false,
  onRemove = null,
  onClick = null
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      padding: "5px 10px",
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body-s)",
      fontWeight: "var(--w-medium)",
      lineHeight: 1.2,
      borderRadius: "var(--r-2)",
      cursor: onClick ? "pointer" : "default",
      border: `var(--bw) solid ${selected ? "var(--border-focus)" : "var(--border)"}`,
      background: selected ? "var(--citron-900)" : hover && onClick ? "var(--surface-hover)" : "var(--surface)",
      color: selected ? "var(--accent)" : "var(--text-muted)",
      transition: "all var(--dur-fast) var(--ease)"
    }
  }, children, onRemove ? /*#__PURE__*/React.createElement("button", {
    "aria-label": "Quitar",
    onClick: e => {
      e.stopPropagation();
      onRemove();
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 14,
      height: 14,
      padding: 0,
      border: "none",
      background: "transparent",
      color: "currentColor",
      cursor: "pointer",
      opacity: 0.7,
      fontSize: "13px",
      lineHeight: 1
    }
  }, "\xD7") : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/FigureFrame.jsx
try { (() => {
/**
 * FigureFrame — the signature device. Wraps a chart or image in the camera
 * viewfinder brackets, with an optional tracked caption + focus annotation.
 * This is how a figure becomes "the shot" in Narrativas Visuales.
 */
function FigureFrame({
  children,
  caption = null,
  index = null,
  corners = true,
  cornerColor = "var(--accent)"
}) {
  const arm = 22,
    w = 2,
    inset = 0;
  const base = {
    position: "absolute",
    width: arm,
    height: arm,
    pointerEvents: "none",
    zIndex: 2
  };
  return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--s-3)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      padding: "var(--s-4)",
      background: "var(--carbon-950)",
      border: "var(--bw) solid var(--border)",
      borderRadius: "var(--r-2)"
    }
  }, corners ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      top: inset,
      left: inset,
      borderTop: `${w}px solid ${cornerColor}`,
      borderLeft: `${w}px solid ${cornerColor}`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      top: inset,
      right: inset,
      borderTop: `${w}px solid ${cornerColor}`,
      borderRight: `${w}px solid ${cornerColor}`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      bottom: inset,
      left: inset,
      borderBottom: `${w}px solid ${cornerColor}`,
      borderLeft: `${w}px solid ${cornerColor}`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      bottom: inset,
      right: inset,
      borderBottom: `${w}px solid ${cornerColor}`,
      borderRight: `${w}px solid ${cornerColor}`
    }
  })) : null, children), caption ? /*#__PURE__*/React.createElement("figcaption", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "var(--s-3)"
    }
  }, index != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label-s)",
      fontWeight: "var(--w-bold)",
      letterSpacing: "var(--tracking-wide)",
      color: "var(--accent)",
      flexShrink: 0
    }
  }, index) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-caption)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: "var(--text-faint)",
      lineHeight: 1.5
    }
  }, caption)) : null);
}
Object.assign(__ds_scope, { FigureFrame });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/FigureFrame.jsx", error: String((e && e.message) || e) }); }

// components/data/ProgressTrack.jsx
try { (() => {
/**
 * ProgressTrack — a segmented track for the 16-week course arc.
 * Filled = completed (citron), current = outlined citron, rest = context.
 */
function ProgressTrack({
  total = 16,
  current = 1,
  label = null
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--s-3)",
      width: "100%"
    }
  }, label ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label-s)",
      fontWeight: "var(--w-semibold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-faint)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--fs-subtitle)",
      fontWeight: "var(--w-medium)",
      color: "var(--accent)",
      fontVariantNumeric: "tabular-nums"
    }
  }, String(current).padStart(2, "0"), " / ", total)) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "3px"
    }
  }, Array.from({
    length: total
  }).map((_, i) => {
    const n = i + 1;
    const done = n < current;
    const now = n === current;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        flex: 1,
        height: 6,
        borderRadius: "var(--r-1)",
        background: done ? "var(--accent)" : now ? "transparent" : "var(--carbon-700)",
        border: now ? "var(--bw) solid var(--accent)" : "none",
        boxSizing: "border-box",
        transition: "background var(--dur) var(--ease)"
      }
    });
  })));
}
Object.assign(__ds_scope, { ProgressTrack });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProgressTrack.jsx", error: String((e && e.message) || e) }); }

// components/data/Stat.jsx
try { (() => {
/**
 * Stat — a single number that carries a story. Display type, tabular figures.
 * `emphasis` makes the value citron (the focus); otherwise it stays bone.
 */
function Stat({
  value,
  label = null,
  delta = null,
  deltaTone = "auto",
  emphasis = false,
  align = "left"
}) {
  let tone = deltaTone;
  if (delta != null && deltaTone === "auto") {
    const n = parseFloat(String(delta).replace(/[^0-9.\-]/g, ""));
    tone = n < 0 ? "down" : "up";
  }
  const deltaColor = tone === "down" ? "var(--signal-negative)" : "var(--accent)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      textAlign: align,
      alignItems: align === "center" ? "center" : "flex-start"
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label-s)",
      fontWeight: "var(--w-semibold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-faint)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--w-light)",
      fontSize: "var(--fs-display-m)",
      lineHeight: 0.95,
      color: emphasis ? "var(--accent)" : "var(--text)",
      fontFeatureSettings: "var(--fnum)",
      fontVariantNumeric: "tabular-nums"
    }
  }, value), delta != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body-s)",
      fontWeight: "var(--w-semibold)",
      color: deltaColor,
      fontFeatureSettings: "var(--fnum)"
    }
  }, tone === "down" ? "▾" : "▴", " ", delta) : null);
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Stat.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
/** Checkbox — square, citron when checked. */
function Checkbox({
  checked = false,
  onChange,
  label = null,
  disabled = false,
  id
}) {
  const cbId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: cbId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body)",
      color: "var(--text)"
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: cbId,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "var(--r-1)",
      border: `var(--bw-2) solid ${checked ? "var(--accent)" : "var(--border-strong)"}`,
      background: checked ? "var(--accent)" : "transparent",
      transition: "all var(--dur-fast) var(--ease)"
    }
  }, checked ? /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 12 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2.5 6.2L5 8.7L9.5 3.5",
    stroke: "var(--text-on-accent)",
    strokeWidth: "2",
    strokeLinecap: "square"
  })) : null), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — text field with optional tracked label + hint. Sharp, carbon surface.
 */
function Input({
  label = null,
  hint = null,
  error = null,
  value,
  onChange,
  placeholder = "",
  type = "text",
  disabled = false,
  iconLeft = null,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || React.useId();
  const borderColor = error ? "var(--signal-negative)" : focus ? "var(--border-focus)" : "var(--border-strong)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "7px",
      width: "100%"
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label)",
      fontWeight: "var(--w-semibold)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--text-faint)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
      background: "var(--surface)",
      border: `var(--bw) solid ${borderColor}`,
      borderRadius: "var(--r-2)",
      padding: "0 14px",
      transition: "border-color var(--dur-fast) var(--ease)",
      opacity: disabled ? 0.5 : 1
    }
  }, iconLeft ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--text-faint)"
    }
  }, iconLeft) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      background: "transparent",
      border: "none",
      outline: "none",
      color: "var(--text)",
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body)",
      padding: "12px 0",
      lineHeight: 1.3
    }
  }, rest))), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-caption)",
      color: "var(--signal-negative)"
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-caption)",
      color: "var(--text-faint)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
/** Radio — round, citron dot when selected. */
function Radio({
  checked = false,
  onChange,
  label = null,
  name,
  value,
  disabled = false,
  id
}) {
  const rId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: rId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body)",
      color: "var(--text)"
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: rId,
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    disabled: disabled,
    onChange: () => onChange && onChange(value),
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flexShrink: 0,
      borderRadius: "var(--r-full)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: `var(--bw-2) solid ${checked ? "var(--accent)" : "var(--border-strong)"}`,
      background: "transparent",
      transition: "all var(--dur-fast) var(--ease)"
    }
  }, checked ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: "var(--r-full)",
      background: "var(--accent)"
    }
  }) : null), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select — native select styled to match Input. Tracked label optional.
 */
function Select({
  label = null,
  value,
  onChange,
  options = [],
  disabled = false,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const selId = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "7px",
      width: "100%"
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: selId,
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label)",
      fontWeight: "var(--w-semibold)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--text-faint)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: selId,
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      appearance: "none",
      WebkitAppearance: "none",
      background: "var(--surface)",
      border: `var(--bw) solid ${focus ? "var(--border-focus)" : "var(--border-strong)"}`,
      borderRadius: "var(--r-2)",
      color: "var(--text)",
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body)",
      padding: "12px 40px 12px 14px",
      lineHeight: 1.3,
      cursor: "pointer",
      transition: "border-color var(--dur-fast) var(--ease)",
      outline: "none"
    }
  }, rest), options.map(o => {
    const val = typeof o === "string" ? o : o.value;
    const lab = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val,
      style: {
        background: "var(--carbon-850)",
        color: "var(--text)"
      }
    }, lab);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 14,
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--text-faint)",
      fontSize: "12px"
    }
  }, "\u25BE")));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
/** Switch — sliding toggle, citron track when on. */
function Switch({
  checked = false,
  onChange,
  label = null,
  disabled = false,
  id
}) {
  const sId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: sId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "12px",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body)",
      color: "var(--text)"
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: sId,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 22,
      flexShrink: 0,
      borderRadius: "var(--r-full)",
      background: checked ? "var(--accent)" : "var(--carbon-700)",
      border: `var(--bw) solid ${checked ? "var(--accent)" : "var(--border-strong)"}`,
      position: "relative",
      transition: "all var(--dur) var(--ease)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: checked ? 20 : 2,
      width: 16,
      height: 16,
      borderRadius: "var(--r-full)",
      background: checked ? "var(--text-on-accent)" : "var(--bone-300)",
      transition: "left var(--dur) var(--ease), background var(--dur) var(--ease)"
    }
  })), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Callout.jsx
try { (() => {
/**
 * Callout — bordered aside for notes, ethics warnings, tips.
 * Left rule in the tone color; used for the course's ethics through-line.
 */
function Callout({
  children,
  tone = "note",
  title = null
}) {
  const tones = {
    note: {
      rule: "var(--border-strong)",
      label: "var(--text-faint)",
      labelText: "Nota"
    },
    focus: {
      rule: "var(--accent)",
      label: "var(--accent)",
      labelText: "Clave"
    },
    ethics: {
      rule: "var(--signal-negative)",
      label: "var(--signal-negative)",
      labelText: "Ética"
    }
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--s-4)",
      background: "var(--surface-2)",
      borderLeft: `var(--bw-2) solid ${tones.rule}`,
      borderRadius: "0 var(--r-2) var(--r-2) 0",
      padding: "var(--s-4) var(--s-5)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label-s)",
      fontWeight: "var(--w-semibold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: tones.label,
      marginBottom: "var(--s-2)"
    }
  }, title || tones.labelText), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-body)",
      lineHeight: "var(--lh-body)",
      color: "var(--text-muted)"
    }
  }, children)));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Callout.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
/**
 * Card — carbon surface panel. Optional eyebrow label + viewfinder frame.
 * The `framed` prop draws the citron viewfinder brackets (the brand device).
 */
function Card({
  children,
  eyebrow = null,
  title = null,
  framed = false,
  interactive = false,
  padding = "var(--s-6)",
  onClick = null
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      background: "var(--surface)",
      border: `var(--bw) solid ${interactive && hover ? "var(--border-strong)" : "var(--border)"}`,
      borderRadius: "var(--r-2)",
      padding,
      cursor: interactive ? "pointer" : "default",
      transition: "border-color var(--dur) var(--ease), transform var(--dur) var(--ease)",
      transform: interactive && hover ? "translateY(-2px)" : "none"
    }
  }, framed ? /*#__PURE__*/React.createElement(FrameCorners, null) : null, eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "var(--fs-label-s)",
      fontWeight: "var(--w-semibold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--accent)",
      marginBottom: "var(--s-3)"
    }
  }, eyebrow) : null, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--w-light)",
      fontSize: "var(--fs-title)",
      lineHeight: "var(--lh-title)",
      color: "var(--text)",
      margin: "0 0 var(--s-3)"
    }
  }, title) : null, children);
}
function FrameCorners() {
  const arm = 18,
    w = 2,
    inset = 9,
    c = "var(--accent)";
  const base = {
    position: "absolute",
    width: arm,
    height: arm,
    pointerEvents: "none"
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      top: inset,
      left: inset,
      borderTop: `${w}px solid ${c}`,
      borderLeft: `${w}px solid ${c}`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      top: inset,
      right: inset,
      borderTop: `${w}px solid ${c}`,
      borderRight: `${w}px solid ${c}`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      bottom: inset,
      left: inset,
      borderBottom: `${w}px solid ${c}`,
      borderLeft: `${w}px solid ${c}`
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      bottom: inset,
      right: inset,
      borderBottom: `${w}px solid ${c}`,
      borderRight: `${w}px solid ${c}`
    }
  }));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Tabs.jsx
try { (() => {
/** Tabs — underline-style nav. Active tab gets a citron rule. */
function Tabs({
  tabs = [],
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--s-6)",
      borderBottom: "var(--bw) solid var(--border)"
    }
  }, tabs.map(t => {
    const val = typeof t === "string" ? t : t.value;
    const lab = typeof t === "string" ? t : t.label;
    const active = val === value;
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      onClick: () => onChange && onChange(val),
      style: {
        background: "none",
        border: "none",
        cursor: "pointer",
        padding: "0 0 var(--s-3)",
        marginBottom: "-1px",
        fontFamily: "var(--font-text)",
        fontSize: "var(--fs-body-s)",
        fontWeight: "var(--w-semibold)",
        letterSpacing: "var(--tracking-eyebrow)",
        textTransform: "uppercase",
        color: active ? "var(--text)" : "var(--text-faint)",
        borderBottom: `var(--bw-2) solid ${active ? "var(--accent)" : "transparent"}`,
        transition: "color var(--dur-fast) var(--ease)"
      }
    }, lab);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/curso/screens.jsx
try { (() => {
/* Course hub screens for Narrativas Visuales.
   Composes DS primitives from window.NarrativasVisualesDesignSystem_47c612.
   Exposed on window for index.html to mount. */
(function () {
  const NV = window.NarrativasVisualesDesignSystem_47c612;
  const {
    Badge,
    Button,
    IconButton,
    Tag,
    Card,
    Callout,
    Tabs,
    Stat,
    FigureFrame,
    ProgressTrack
  } = NV;
  const Ico = ({
    n,
    s = 18,
    c = "currentColor"
  }) => /*#__PURE__*/React.createElement("i", {
    "data-lucide": n,
    style: {
      width: s,
      height: s,
      color: c
    }
  });

  /* ---- 16-week syllabus (abbreviated content, real structure) ---- */
  const WEEKS = [{
    n: 1,
    title: "Del dato a la decisión",
    part: "Fundamentos"
  }, {
    n: 2,
    title: "Contexto y audiencia",
    part: "Fundamentos"
  }, {
    n: 3,
    title: "Elegir el gráfico correcto",
    part: "Fundamentos"
  }, {
    n: 4,
    title: "Eliminar el desorden",
    part: "Fundamentos"
  }, {
    n: 5,
    title: "Dirigir la atención",
    part: "Fundamentos"
  }, {
    n: 6,
    title: "Pensar como diseñador",
    part: "Fundamentos"
  }, {
    n: 7,
    title: "La historia en los datos",
    part: "Fundamentos"
  }, {
    n: 8,
    title: "Taller integrador I",
    part: "Fundamentos"
  }, {
    n: 9,
    title: "Planear la presentación",
    part: "Presentación"
  }, {
    n: 10,
    title: "Construir el mensaje",
    part: "Presentación"
  }, {
    n: 11,
    title: "Diseñar las láminas",
    part: "Presentación"
  }, {
    n: 12,
    title: "Entregar con presencia",
    part: "Presentación"
  }, {
    n: 13,
    title: "IA como acelerador",
    part: "Presentación"
  }, {
    n: 14,
    title: "Prototipos con IA",
    part: "Presentación"
  }, {
    n: 15,
    title: "Ética en la comunicación",
    part: "Presentación"
  }, {
    n: 16,
    title: "Presentación final",
    part: "Presentación"
  }];

  /* ======================= SIDEBAR ======================= */
  function Sidebar({
    current,
    onSelect,
    done
  }) {
    return /*#__PURE__*/React.createElement("aside", {
      style: {
        width: 300,
        flexShrink: 0,
        height: "100%",
        boxSizing: "border-box",
        background: "var(--carbon-950)",
        borderRight: "1px solid var(--border)",
        display: "flex",
        flexDirection: "column"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "26px 24px 20px",
        borderBottom: "1px solid var(--border)"
      }
    }, /*#__PURE__*/React.createElement(Wordmark, null)), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "20px 24px 8px"
      }
    }, /*#__PURE__*/React.createElement(ProgressTrack, {
      total: 16,
      current: current,
      label: "Progreso"
    })), /*#__PURE__*/React.createElement("nav", {
      style: {
        flex: 1,
        overflowY: "auto",
        padding: "12px 14px 24px"
      }
    }, ["Fundamentos", "Presentación"].map(part => /*#__PURE__*/React.createElement("div", {
      key: part,
      style: {
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "10px 10px 8px",
        fontFamily: "var(--font-text)",
        fontSize: 10,
        letterSpacing: "var(--tracking-label)",
        textTransform: "uppercase",
        color: "var(--text-faint)"
      }
    }, part), WEEKS.filter(w => w.part === part).map(w => {
      const active = w.n === current;
      const isDone = done.includes(w.n);
      return /*#__PURE__*/React.createElement("button", {
        key: w.n,
        onClick: () => onSelect(w.n),
        style: {
          width: "100%",
          textAlign: "left",
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "10px 10px",
          marginBottom: 2,
          cursor: "pointer",
          background: active ? "var(--surface-hover)" : "transparent",
          border: "1px solid " + (active ? "var(--border)" : "transparent"),
          borderLeft: "2px solid " + (active ? "var(--accent)" : "transparent"),
          borderRadius: "var(--r-1)",
          transition: "background var(--dur-fast) var(--ease)"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 22,
          height: 22,
          flexShrink: 0,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: "var(--font-display)",
          fontSize: 15,
          fontVariantNumeric: "tabular-nums",
          color: isDone ? "var(--accent)" : active ? "var(--text)" : "var(--text-faint)",
          border: "1px solid " + (isDone ? "var(--border-focus)" : "var(--border)"),
          borderRadius: "var(--r-1)"
        }
      }, isDone ? "✓" : String(w.n).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: "var(--font-text)",
          fontSize: 13.5,
          lineHeight: 1.25,
          color: active ? "var(--text)" : "var(--text-muted)",
          fontWeight: active ? 600 : 400
        }
      }, w.title));
    })))));
  }
  function Wordmark() {
    const arm = 12,
      w = 2,
      c = "var(--accent)";
    const cn = extra => ({
      position: "absolute",
      width: arm,
      height: arm,
      ...extra
    });
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        width: 44,
        height: 44,
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: cn({
        top: 0,
        left: 0,
        borderTop: `${w}px solid ${c}`,
        borderLeft: `${w}px solid ${c}`
      })
    }), /*#__PURE__*/React.createElement("span", {
      style: cn({
        top: 0,
        right: 0,
        borderTop: `${w}px solid ${c}`,
        borderRight: `${w}px solid ${c}`
      })
    }), /*#__PURE__*/React.createElement("span", {
      style: cn({
        bottom: 0,
        left: 0,
        borderBottom: `${w}px solid ${c}`,
        borderLeft: `${w}px solid ${c}`
      })
    }), /*#__PURE__*/React.createElement("span", {
      style: cn({
        bottom: 0,
        right: 0,
        borderBottom: `${w}px solid ${c}`,
        borderRight: `${w}px solid ${c}`
      })
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 400,
        fontSize: 21,
        color: "var(--bone-000)",
        lineHeight: 1
      }
    }, "NV")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 300,
        fontSize: 20,
        lineHeight: 0.95,
        textTransform: "uppercase",
        color: "var(--text)"
      }
    }, "Narrativas", /*#__PURE__*/React.createElement("br", null), "Visuales")));
  }

  /* ======================= SESSION VIEW ======================= */
  function BarChart({
    focus
  }) {
    const data = [{
      l: "L1",
      v: 42
    }, {
      l: "L2",
      v: 55
    }, {
      l: "L3",
      v: 61
    }, {
      l: "L4",
      v: 48
    }, {
      l: "L5",
      v: 73
    }, {
      l: "L6",
      v: 94
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-end",
        gap: 18,
        height: 240,
        padding: "10px 6px"
      }
    }, data.map((d, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "flex-end"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: "100%",
        height: `${d.v}%`,
        borderRadius: "2px 2px 0 0",
        background: focus && i === 5 ? "var(--accent)" : "var(--carbon-600)",
        transition: "background var(--dur) var(--ease)"
      }
    }), focus && i === 5 ? /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        top: -6,
        left: "50%",
        transform: "translateX(-50%)",
        fontFamily: "var(--font-text)",
        fontSize: 12,
        fontWeight: 700,
        color: "var(--accent)"
      }
    }, "94%") : null), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-text)",
        fontSize: 11,
        letterSpacing: "0.08em",
        color: focus && i === 5 ? "var(--accent)" : "var(--text-faint)"
      }
    }, d.l))));
  }
  function SessionView({
    week,
    tab,
    onTab,
    focus,
    onFocus,
    isDone,
    onToggleDone
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: "auto",
        height: "100%"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "36px 44px 26px",
        borderBottom: "1px solid var(--border)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "focus",
      solid: true
    }, "Semana " + String(week.n).padStart(2, "0")), /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral"
    }, week.part)), /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 300,
        fontSize: 60,
        lineHeight: 0.95,
        textTransform: "uppercase",
        color: "var(--text)",
        margin: "0 0 16px",
        maxWidth: 900
      }
    }, week.title), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: "var(--font-text)",
        fontSize: 19,
        lineHeight: 1.5,
        color: "var(--text-muted)",
        maxWidth: "60ch",
        margin: 0
      }
    }, "Apertura narrativa breve, pr\xE1ctica activa intensiva. Pasa de mostrar el dato a mover una decisi\xF3n."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        marginTop: 26
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      iconRight: /*#__PURE__*/React.createElement(Ico, {
        n: "arrow-right",
        s: 16
      })
    }, "Empezar sesi\xF3n"), /*#__PURE__*/React.createElement(Button, {
      variant: isDone ? "secondary" : "ghost",
      onClick: onToggleDone,
      iconLeft: /*#__PURE__*/React.createElement(Ico, {
        n: isDone ? "check" : "circle",
        s: 16
      })
    }, isDone ? "Completada" : "Marcar completa"))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "28px 44px 60px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 26
      }
    }, /*#__PURE__*/React.createElement(Tabs, {
      value: tab,
      onChange: onTab,
      tabs: [{
        value: "sesion",
        label: "La sesión"
      }, {
        value: "caso",
        label: "Caso"
      }, {
        value: "entrega",
        label: "Entrega"
      }]
    })), tab === "sesion" ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1.5fr 1fr",
        gap: 26,
        alignItems: "start"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement(FigureFrame, {
      index: "FIG 05",
      caption: "Rendimiento por lote \u2014 el lote 6 es el punto de decisi\xF3n"
    }, /*#__PURE__*/React.createElement(BarChart, {
      focus: focus
    })), /*#__PURE__*/React.createElement(Callout, {
      tone: "focus",
      title: "El movimiento"
    }, "Un solo cambio \u2014 todo a gris, una barra en citr\xF3n \u2014 convierte una tabla en una historia. El ojo va directo a la decisi\xF3n.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 18
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Enfoca la toma",
      padding: "var(--s-5)"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-text)",
        fontSize: 14,
        color: "var(--text-muted)"
      }
    }, "Resaltar el foco"), /*#__PURE__*/React.createElement(NV.Switch, {
      checked: focus,
      onChange: onFocus
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 24
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      label: "Rendimiento",
      value: "94%",
      delta: "+12 pts",
      emphasis: focus
    }), /*#__PURE__*/React.createElement(Stat, {
      label: "Fuera de rango",
      value: "3",
      delta: "-40%"
    }))), /*#__PURE__*/React.createElement(Callout, {
      tone: "ethics"
    }, "Una escala truncada o un color enga\xF1oso puede subestimar un riesgo. La \xE9tica es el hilo conductor del curso."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Tag, null, "Storytelling with Data"), /*#__PURE__*/React.createElement(Tag, null, "Preattentive"), /*#__PURE__*/React.createElement(Tag, {
      selected: true,
      onClick: () => {}
    }, "Foco")))) : tab === "caso" ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 18
      }
    }, [{
      e: "Biorreactor",
      t: "Eficiencia bajo presión",
      d: "De 12 variables de proceso a la única que mueve el rendimiento."
    }, {
      e: "Vida útil",
      t: "El lote que decide",
      d: "Una serie temporal que le dice a calidad cuándo actuar."
    }, {
      e: "Inocuidad",
      t: "El riesgo invisible",
      d: "Cómo una visualización honesta evita una decisión equivocada."
    }, {
      e: "Sensores",
      t: "Ruido vs señal",
      d: "Reducir mil puntos a la tendencia que importa."
    }].map((c, i) => /*#__PURE__*/React.createElement(Card, {
      key: i,
      eyebrow: c.e,
      title: c.t,
      interactive: true,
      framed: i === 0
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontFamily: "var(--font-text)",
        fontSize: 15,
        lineHeight: 1.55,
        color: "var(--text-muted)"
      }
    }, c.d)))) : /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 640,
        display: "flex",
        flexDirection: "column",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Entrega de la semana"
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: "0 0 20px",
        fontFamily: "var(--font-text)",
        fontSize: 15,
        lineHeight: 1.55,
        color: "var(--text-muted)"
      }
    }, "Sube un gr\xE1fico redise\xF1ado: de la versi\xF3n cruda a una toma con un solo foco. M\xE1ximo una l\xE1mina."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement(NV.Input, {
      label: "T\xEDtulo de la historia",
      placeholder: "Una frase, no un tema"
    }), /*#__PURE__*/React.createElement(NV.Select, {
      label: "Formato del ejercicio",
      options: ["Análogo (papel)", "Colaborativo (1-2-4)", "Con IA generativa"]
    }), /*#__PURE__*/React.createElement(NV.Checkbox, {
      label: "Incluye una llamada a la acci\xF3n expl\xEDcita",
      checked: true,
      onChange: () => {}
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 22,
        display: "flex",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "primary"
    }, "Enviar entrega"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost"
    }, "Guardar borrador"))))));
  }
  Object.assign(window, {
    Sidebar,
    SessionView,
    WEEKS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/curso/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.FigureFrame = __ds_scope.FigureFrame;

__ds_ns.ProgressTrack = __ds_scope.ProgressTrack;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
