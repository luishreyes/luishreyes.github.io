# Manual de identidad — extracted text (provenance)

Source: `uploads/Manual de identidad.pdf` — "Luis H. Reyes · Fotografía", Manual de Identidad v1.0, Julio 2026.
This is the full text extracted from the 7-page PDF. Page renders could not be rasterized in-sandbox; the design system is built from this text (palette hexes, type specs, motif descriptions are all present and precise).

## 02 — El logotipo
Nombre en tipografía condensada fina (Big Shoulders Display 300) + símbolo del visor: las cuatro esquinas del encuadre de una cámara enmarcando la H de Humberto. La H es la inicial del centro del nombre — el punto de enfoque. El logotipo vive en amarillo citrón sobre negro carbón, nunca hueco ni engrosado.

## 03 — Construcción y espacio
Área de seguridad: margen mínimo "x" = ancho de una esquina del visor. Esquinas = 1/10 del lado del símbolo, trazo = 1/12. La H ocupa la mitad de la altura. Tamaños mínimos: 64px con visor, 32px solo H, 16px favicon. Bajo 48px se elimina el visor y sube el peso de la H (300→400→500). Impresión: símbolo nunca < 12mm, apilado ≥ 30mm de ancho.

## 04 — Color
- AMARILLO CITRÓN — #C9C41C · RGB 201/196/28 · CMYK 0/2/86/21
- NEGRO CARBÓN — #0A0A0A · RGB 10/10/10 · CMYK 0/0/0/96
- BLANCO HUESO — #E8E6E1 · RGB 232/230/225 · CMYK 0/1/3/10
- Proporción de uso: 70% negro / 20% blanco / 10% amarillo.
- El negro es el escenario. El blanco hueso es texto y aire. El amarillo es solo acento (titulares, símbolo, un enlace). Nunca como fondo de grandes superficies, nunca junto a otros colores saturados.

## 05 — Tipografía
- Titulares: Big Shoulders Display — Fina 200, Regular 300, Media 400, Fuerte 500.
- Etiquetas y texto: Archivo — Medium 500, Semibold 600, Bold 700.
- Jerarquía: Titular (uppercase), Etiqueta (tracked uppercase "S E R I E — E S T U D I O S"), Cuerpo.
- Frase de marca: "Hay una versión de cada escena que solo aparece cuando le quitas el color. Esa es la que busco."

## 06 — Usos incorrectos
No engrosar la letra (la finura es la marca). No usar contorno hueco. No cambiar el amarillo citrón. No rotar/inclinar el símbolo. No estirar/condensar. No aplicar sobre fondos claros o fotos sin oscurecer. Regla: amarillo citrón fino sobre negro carbón; sobre fotografía solo en zonas oscuras o con velo negro al 40%; blanco hueso solo cuando el amarillo no tenga contraste.

## 07 — Aplicaciones
- Avatar Instagram: 1080×1080, fondo del símbolo un punto más claro (#141412).
- Favicon: 64/32/16px; desde 32px solo la H con peso aumentado.
- Marca de agua en fotografía: esquina inferior derecha, 90% opacidad, sobre zona oscura.
- Firma/encabezado web: versión horizontal (nombre + etiqueta, sin símbolo).
